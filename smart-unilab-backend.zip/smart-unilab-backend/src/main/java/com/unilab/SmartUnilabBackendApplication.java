package com.unilab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartUnilabBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartUnilabBackendApplication.class, args);
	}

}
