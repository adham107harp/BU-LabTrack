
  # Lab Tracking System Website

  This is a code bundle for Lab Tracking System Website. The original project is available at https://www.figma.com/design/v0WBBhM5J0F8utNlNpAf19/Lab-Tracking-System-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  