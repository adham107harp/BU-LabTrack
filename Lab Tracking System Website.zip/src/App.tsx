import { useState, createContext, useContext } from 'react';
import { Login } from './components/Login';
import { MainApp } from './components/MainApp';
import { AboutLanding } from './components/AboutLanding';

export type UserRole = 'student' | 'doctor';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface DarkModeContextType {
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const DarkModeContext = createContext<DarkModeContextType>({
  darkMode: false,
  toggleDarkMode: () => {},
});

export const useDarkMode = () => useContext(DarkModeContext);

export default function App() {
  const [currentView, setCurrentView] = useState<'about' | 'login' | 'app'>('about');
  const [user, setUser] = useState<User | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentView('app');
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <DarkModeContext.Provider value={{ darkMode, toggleDarkMode }}>
      <div className={darkMode ? 'dark' : ''}>
        {currentView === 'about' && <AboutLanding onGetStarted={() => setCurrentView('login')} />}
        {(currentView === 'login' || !user) && currentView !== 'about' && <Login onLogin={handleLogin} />}
        {currentView === 'app' && user && (
          <MainApp
            user={user}
            onLogout={() => {
              setUser(null);
              setCurrentView('about');
            }}
          />
        )}
      </div>
    </DarkModeContext.Provider>
  );
}
