import { useState } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { User } from '../App';

interface Lab {
  id: number;
  name: string;
  capacity: number;
  building: string;
  floor: number;
  status: 'available' | 'occupied' | 'maintenance';
  equipment: Equipment[];
}

interface Equipment {
  id: number;
  name: string;
  quantity: number;
  available: number;
}

interface LabRoomsProps {
  user: User;
  onNavigateToReservation: () => void;
}

export function LabRooms({ user, onNavigateToReservation }: LabRoomsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLab, setSelectedLab] = useState<Lab | null>(null);

  const [labs] = useState<Lab[]>([
    {
      id: 1,
      name: 'Computer Lab',
      capacity: 40,
      building: 'Engineering Building',
      floor: 2,
      status: 'available',
      equipment: [
        { id: 1, name: 'PC Workstation', quantity: 40, available: 35 },
        { id: 2, name: 'Dual Monitor Setup', quantity: 20, available: 18 },
        { id: 3, name: 'High-Performance PC', quantity: 10, available: 8 },
        { id: 4, name: 'Programming Software License', quantity: 40, available: 40 },
      ],
    },
    {
      id: 2,
      name: 'Physics Lab',
      capacity: 30,
      building: 'Science Building',
      floor: 3,
      status: 'available',
      equipment: [
        { id: 5, name: 'Oscilloscope', quantity: 12, available: 10 },
        { id: 6, name: 'Multimeter', quantity: 20, available: 18 },
        { id: 7, name: 'Function Generator', quantity: 8, available: 6 },
        { id: 8, name: 'Power Supply Unit', quantity: 15, available: 13 },
        { id: 9, name: 'Experiment Kit A', quantity: 10, available: 8 },
        { id: 10, name: 'Experiment Kit B', quantity: 10, available: 7 },
      ],
    },
    {
      id: 3,
      name: 'Digital Logic Design Lab',
      capacity: 35,
      building: 'Engineering Building',
      floor: 1,
      status: 'available',
      equipment: [
        { id: 11, name: 'FPGA Development Board', quantity: 20, available: 16 },
        { id: 12, name: 'Logic Analyzer', quantity: 10, available: 8 },
        { id: 13, name: 'Breadboard Kit', quantity: 30, available: 25 },
        { id: 14, name: 'Arduino Uno', quantity: 25, available: 20 },
        { id: 15, name: 'Raspberry Pi 4', quantity: 15, available: 12 },
      ],
    },
    {
      id: 4,
      name: 'Chemistry Lab A',
      capacity: 30,
      building: 'Science Building',
      floor: 2,
      status: 'occupied',
      equipment: [
        { id: 16, name: 'Bunsen Burner', quantity: 15, available: 5 },
        { id: 17, name: 'Beakers (500ml)', quantity: 30, available: 12 },
        { id: 18, name: 'pH Meter', quantity: 10, available: 3 },
        { id: 19, name: 'Pipettes', quantity: 25, available: 8 },
      ],
    },
    {
      id: 5,
      name: 'Biology Lab A',
      capacity: 28,
      building: 'Science Building',
      floor: 1,
      status: 'available',
      equipment: [
        { id: 20, name: 'Microscope', quantity: 20, available: 18 },
        { id: 21, name: 'Petri Dishes', quantity: 100, available: 85 },
        { id: 22, name: 'Centrifuge', quantity: 8, available: 6 },
        { id: 23, name: 'Incubator', quantity: 4, available: 3 },
      ],
    },
    {
      id: 6,
      name: 'Robotics Lab',
      capacity: 25,
      building: 'Engineering Building',
      floor: 1,
      status: 'available',
      equipment: [
        { id: 24, name: 'Robot Arm Kit', quantity: 10, available: 8 },
        { id: 25, name: 'Motor Driver', quantity: 20, available: 16 },
        { id: 26, name: '3D Printer', quantity: 3, available: 2 },
        { id: 27, name: 'Soldering Station', quantity: 10, available: 8 },
      ],
    },
    {
      id: 7,
      name: 'Mechanical Lab',
      capacity: 35,
      building: 'Engineering Building',
      floor: 3,
      status: 'available',
      equipment: [
        { id: 28, name: 'CNC Machine', quantity: 2, available: 2 },
        { id: 29, name: 'Lathe', quantity: 4, available: 3 },
        { id: 30, name: 'Welding Equipment', quantity: 6, available: 5 },
        { id: 31, name: 'Drill Press', quantity: 8, available: 7 },
      ],
    },
    {
      id: 8,
      name: 'Electronics Lab',
      capacity: 30,
      building: 'Engineering Building',
      floor: 2,
      status: 'maintenance',
      equipment: [
        { id: 32, name: 'Component Kit', quantity: 30, available: 0 },
        { id: 33, name: 'PCB Design Station', quantity: 15, available: 0 },
      ],
    },
    {
      id: 9,
      name: 'Chemistry Lab B',
      capacity: 30,
      building: 'Science Building',
      floor: 2,
      status: 'available',
      equipment: [
        { id: 34, name: 'Spectrophotometer', quantity: 6, available: 4 },
        { id: 35, name: 'Fume Hood', quantity: 8, available: 8 },
        { id: 36, name: 'Hot Plate', quantity: 12, available: 10 },
      ],
    },
    {
      id: 10,
      name: 'Biology Lab B',
      capacity: 28,
      building: 'Science Building',
      floor: 1,
      status: 'available',
      equipment: [
        { id: 37, name: 'DNA Extraction Kit', quantity: 15, available: 12 },
        { id: 38, name: 'PCR Machine', quantity: 3, available: 2 },
        { id: 39, name: 'Gel Electrophoresis Unit', quantity: 6, available: 5 },
      ],
    },
    {
      id: 11,
      name: 'Data Science Lab',
      capacity: 35,
      building: 'Engineering Building',
      floor: 4,
      status: 'available',
      equipment: [
        { id: 40, name: 'High-Performance Workstation', quantity: 20, available: 18 },
        { id: 41, name: 'GPU Server Access', quantity: 35, available: 35 },
        { id: 42, name: 'Data Analytics Software', quantity: 35, available: 35 },
      ],
    },
    {
      id: 12,
      name: 'Materials Lab',
      capacity: 20,
      building: 'Science Building',
      floor: 4,
      status: 'available',
      equipment: [
        { id: 43, name: 'X-Ray Diffractometer', quantity: 1, available: 1 },
        { id: 44, name: 'SEM Microscope', quantity: 1, available: 1 },
        { id: 45, name: 'Tensile Testing Machine', quantity: 2, available: 2 },
      ],
    },
    ...(user.role === 'doctor' ? [{
      id: 13,
      name: 'Research Lab',
      capacity: 15,
      building: 'Research Center',
      floor: 1,
      status: 'available' as const,
      equipment: [
        { id: 46, name: 'Mass Spectrometer', quantity: 2, available: 2 },
        { id: 47, name: 'NMR Spectrometer', quantity: 1, available: 1 },
        { id: 48, name: 'HPLC System', quantity: 3, available: 2 },
        { id: 49, name: 'Advanced Microscopy Suite', quantity: 5, available: 4 },
        { id: 50, name: 'Ultra-Centrifuge', quantity: 2, available: 2 },
      ],
    }] : []),
  ]);

  const filteredLabs = labs.filter((lab) =>
    lab.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lab.building.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: Lab['status']) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 text-green-700 border-green-300 dark:bg-green-900 dark:text-green-300 dark:border-green-700';
      case 'occupied':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300 dark:bg-yellow-900 dark:text-yellow-300 dark:border-yellow-700';
      case 'maintenance':
        return 'bg-red-100 text-red-700 border-red-300 dark:bg-red-900 dark:text-red-300 dark:border-red-700';
    }
  };

  const handleMakeReservation = (equipment: Equipment) => {
    localStorage.setItem('selectedEquipment', JSON.stringify({
      ...equipment,
      labName: selectedLab?.name,
      labId: selectedLab?.id,
    }));
    setSelectedEquipment(null);
    setSelectedLab(null);
    onNavigateToReservation();
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-[#51829B] dark:text-[#9BB0C1]">Lab Rooms</h1>
        <p className="text-gray-600 dark:text-[#B0B0B0] mt-1">Browse and access laboratory facilities</p>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-[#252932] rounded-lg shadow p-4 border-2 border-[#EADFB4] dark:border-[#3A4150]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-[#B0B0B0] w-5 h-5" />
          <input
            type="text"
            placeholder="Search labs by name or building..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1]"
          />
        </div>
      </div>

      {/* Labs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredLabs.map((lab, index) => (
          <div
            key={lab.id}
            className="bg-white dark:bg-[#252932] rounded-lg shadow hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer animate-scaleIn border-2 border-[#EADFB4] dark:border-[#3A4150]"
            style={{ animationDelay: `${index * 0.05}s` }}
            onClick={() => setSelectedLab(lab)}
          >
            <div className="p-6">
              <h3 className="mb-3 text-[#51829B] dark:text-[#9BB0C1]">{lab.name}</h3>
              
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B0B0B0]">Building:</span>
                  <span className="text-gray-900 dark:text-white">{lab.building}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B0B0B0]">Floor:</span>
                  <span className="text-gray-900 dark:text-white">{lab.floor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B0B0B0]">Capacity:</span>
                  <span className="text-gray-900 dark:text-white">{lab.capacity} students</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B0B0B0]">Equipment:</span>
                  <span className="text-gray-900 dark:text-white">{lab.equipment.length} types</span>
                </div>
              </div>

              <div className={`px-3 py-1 rounded-full text-xs border-2 text-center ${getStatusColor(lab.status)}`}>
                {lab.status.charAt(0).toUpperCase() + lab.status.slice(1)}
              </div>

              <button className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-[#F6995C] to-[#51829B] text-white rounded-lg hover:shadow-lg transition-all">
                View Equipment
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Lab Equipment Modal */}
      {selectedLab && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white dark:bg-[#252932] rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-scaleIn border-2 border-[#F6995C]">
            <div className="sticky top-0 bg-gradient-to-r from-[#51829B] to-[#9BB0C1] text-white p-6 rounded-t-lg">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-white mb-2">{selectedLab.name}</h2>
                  <p className="text-[#EADFB4] text-sm">{selectedLab.building} - Floor {selectedLab.floor}</p>
                </div>
                <button
                  onClick={() => setSelectedLab(null)}
                  className="text-white hover:bg-white/20 rounded-full p-2 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <h3 className="mb-4 text-[#51829B] dark:text-[#9BB0C1]">Available Equipment</h3>
              <div className="space-y-3">
                {selectedLab.equipment.map((equipment) => (
                  <div
                    key={equipment.id}
                    className="flex items-center justify-between p-4 bg-[#FAF9F5] dark:bg-[#2F3541] rounded-lg hover:bg-[#EADFB4] dark:hover:bg-[#3A4150] transition-colors border-2 border-[#EADFB4] dark:border-[#3A4150]"
                  >
                    <div className="flex-1">
                      <p className="text-gray-900 dark:text-white">{equipment.name}</p>
                      <p className="text-sm text-gray-600 dark:text-[#B0B0B0] mt-1">
                        Available: <span className={equipment.available > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                          {equipment.available} / {equipment.quantity}
                        </span>
                      </p>
                    </div>
                    <button
                      onClick={() => handleMakeReservation(equipment)}
                      disabled={equipment.available === 0}
                      className={`px-4 py-2 rounded-lg transition-all ${
                        equipment.available === 0
                          ? 'bg-gray-200 dark:bg-[#2F3541] text-gray-500 dark:text-[#6B6B6B] cursor-not-allowed'
                          : 'bg-gradient-to-r from-[#F6995C] to-[#51829B] text-white hover:shadow-lg transform hover:scale-105'
                      }`}
                    >
                      {equipment.available === 0 ? 'Not Available' : 'Make Reservation'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}