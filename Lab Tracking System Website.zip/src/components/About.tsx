import { Beaker, CheckCircle, Users, Package, Share2, FlaskConical, Calendar } from 'lucide-react';

export function About() {
  const features = [
    {
      icon: Package,
      title: 'Equipment Reservation',
      description: 'Students can reserve laboratory equipment for their experiments and projects in advance.',
    },
    {
      icon: Share2,
      title: 'Equipment Sharing',
      description: 'Share equipment and resources with fellow students, fostering collaboration and efficient resource use.',
    },
    {
      icon: Beaker,
      title: 'Lab Room Management',
      description: 'View available lab rooms, their capacities, and current status in real-time.',
    },
    {
      icon: FlaskConical,
      title: 'Research Lab Access',
      description: 'Doctors and faculty members have exclusive access to research lab management and advanced equipment.',
    },
    {
      icon: Calendar,
      title: 'Session Tracking',
      description: 'Track all lab sessions, including scheduled, ongoing, and completed activities.',
    },
    {
      icon: Users,
      title: 'User Roles',
      description: 'Role-based access for students and doctors, ensuring appropriate permissions and features.',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg p-8 md:p-12">
        <div className="flex items-center gap-4 mb-4">
          <Beaker className="w-12 h-12" />
          <h1 className="text-white">About Our System</h1>
        </div>
        <p className="text-blue-100 text-lg max-w-3xl">
          The Badya University Laboratory Tracking System is a comprehensive platform designed to streamline 
          laboratory management, equipment reservations, and resource sharing across all departments.
        </p>
      </div>

      {/* Mission Section */}
      <div className="bg-white rounded-lg shadow p-8">
        <h2 className="mb-4">Our Mission</h2>
        <p className="text-gray-700 leading-relaxed">
          We aim to provide an efficient, user-friendly system that enhances the laboratory experience for both 
          students and faculty members. By digitizing lab management and equipment tracking, we reduce conflicts, 
          improve resource utilization, and support academic excellence at Badya University.
        </p>
      </div>

      {/* Features Section */}
      <div>
        <h2 className="mb-6">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 text-blue-600 rounded-lg">
                  <feature.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* How It Works Section */}
      <div className="bg-white rounded-lg shadow p-8">
        <h2 className="mb-6">How It Works</h2>
        <div className="space-y-6">
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center">
              1
            </div>
            <div>
              <h3 className="mb-1">Login to Your Account</h3>
              <p className="text-gray-600">
                Sign in using your university credentials as either a student or doctor to access role-specific features.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center">
              2
            </div>
            <div>
              <h3 className="mb-1">Browse Available Resources</h3>
              <p className="text-gray-600">
                Explore lab rooms, equipment inventory, and check availability in real-time through the dashboard.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center">
              3
            </div>
            <div>
              <h3 className="mb-1">Reserve Equipment</h3>
              <p className="text-gray-600">
                Select the equipment you need, choose your preferred date and time, and submit your reservation request.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center">
              4
            </div>
            <div>
              <h3 className="mb-1">Share with Peers</h3>
              <p className="text-gray-600">
                Post equipment you're willing to share or browse items offered by other students for collaborative work.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="bg-white rounded-lg shadow p-8">
        <h2 className="mb-6">Benefits</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">Reduce conflicts over equipment availability</p>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">Improve laboratory resource utilization</p>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">Foster collaboration among students</p>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">Streamline lab management for faculty</p>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">Track equipment maintenance schedules</p>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">Generate usage reports and analytics</p>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-8">
        <h2 className="mb-4">Need Help?</h2>
        <p className="text-gray-700 mb-4">
          Our support team is here to assist you with any questions or technical issues.
        </p>
        <div className="flex flex-wrap gap-4">
          <div>
            <p className="text-sm text-gray-600">Email Support</p>
            <p className="text-blue-600">labsupport@badya.edu</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Phone</p>
            <p className="text-blue-600">+20 123 456 7890</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Office Hours</p>
            <p className="text-blue-600">Sun - Thu, 9:00 AM - 5:00 PM</p>
          </div>
        </div>
      </div>
    </div>
  );
}
