import { useState } from 'react';
import { Plus, Search, MessageCircle, User as UserIcon } from 'lucide-react';
import { User } from '../App';

interface SharedItem {
  id: number;
  equipmentName: string;
  category: string;
  ownerName: string;
  ownerEmail: string;
  description: string;
  availability: string;
  duration: string;
  condition: string;
  postedDate: string;
}

interface EquipmentSharingProps {
  user: User;
}

export function EquipmentSharing({ user }: EquipmentSharingProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [filter, setFilter] = useState<'all' | 'my-items'>('all');

  const [sharedItems] = useState<SharedItem[]>([
    {
      id: 1,
      equipmentName: 'Digital Multimeter',
      category: 'Electronics',
      ownerName: 'Ahmed Khalil',
      ownerEmail: 'ahmed.k@badya.edu',
      description: 'Barely used digital multimeter, perfect for circuit testing',
      availability: 'Weekends',
      duration: '2-3 hours',
      condition: 'Like New',
      postedDate: '2024-12-10',
    },
    {
      id: 2,
      equipmentName: 'Lab Notebook (Chemistry)',
      category: 'Stationery',
      ownerName: 'Sara Mohamed',
      ownerEmail: 'sara.m@badya.edu',
      description: 'Complete set of chemistry lab notes for CHEM 201',
      availability: 'Available anytime',
      duration: '1 week',
      condition: 'Good',
      postedDate: '2024-12-12',
    },
    {
      id: 3,
      equipmentName: 'Arduino Starter Kit',
      category: 'Robotics',
      ownerName: 'Omar Hassan',
      ownerEmail: 'omar.h@badya.edu',
      description: 'Complete Arduino kit with sensors and modules',
      availability: 'Mon-Wed',
      duration: 'Flexible',
      condition: 'Excellent',
      postedDate: '2024-12-13',
    },
    {
      id: 4,
      equipmentName: 'Safety Goggles',
      category: 'Safety Equipment',
      ownerName: 'Layla Ahmed',
      ownerEmail: 'layla.a@badya.edu',
      description: 'Extra pair of lab safety goggles, never used',
      availability: 'Available anytime',
      duration: 'Per session',
      condition: 'New',
      postedDate: '2024-12-14',
    },
    {
      id: 5,
      equipmentName: 'Soldering Iron',
      category: 'Electronics',
      ownerName: 'Karim Farid',
      ownerEmail: 'karim.f@badya.edu',
      description: 'Professional soldering iron with temperature control',
      availability: 'Thu-Fri',
      duration: '1-2 hours',
      condition: 'Good',
      postedDate: '2024-12-11',
    },
    {
      id: 6,
      equipmentName: 'Physics Formulas Book',
      category: 'Books',
      ownerName: 'Mona Ibrahim',
      ownerEmail: 'mona.i@badya.edu',
      description: 'Comprehensive physics formulas reference book',
      availability: 'Available anytime',
      duration: '2 weeks',
      condition: 'Good',
      postedDate: '2024-12-09',
    }
  ]);

  const myItems = sharedItems.filter(item => item.ownerName === user.name);
  const displayItems = filter === 'my-items' ? myItems : sharedItems;

  const filteredItems = displayItems.filter(item =>
    item.equipmentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleContact = (item: SharedItem) => {
    alert(`Contact ${item.ownerName} at ${item.ownerEmail}`);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-[#8B7355] dark:text-[#C9A87C]">Equipment Sharing</h1>
          <p className="text-gray-600 dark:text-[#B8B8B8] mt-1">Share and borrow equipment with fellow students</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#8B7355] to-[#A0826D] dark:from-[#C9A87C] dark:to-[#A0826D] text-white rounded-lg hover:shadow-lg transition-all duration-300 transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          Share Equipment
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-lg transition-all ${
            filter === 'all'
              ? 'bg-gradient-to-r from-[#8B7355] to-[#A0826D] dark:from-[#C9A87C] dark:to-[#A0826D] text-white'
              : 'bg-white dark:bg-[#2D2D2D] text-gray-700 dark:text-[#B8B8B8] border border-[#E8DCC9] dark:border-[#4A4A4A] hover:bg-[#F5E6D3] dark:hover:bg-[#3D3D3D]'
          }`}
        >
          All Items
        </button>
        <button
          onClick={() => setFilter('my-items')}
          className={`px-4 py-2 rounded-lg transition-all ${
            filter === 'my-items'
              ? 'bg-gradient-to-r from-[#8B7355] to-[#A0826D] dark:from-[#C9A87C] dark:to-[#A0826D] text-white'
              : 'bg-white dark:bg-[#2D2D2D] text-gray-700 dark:text-[#B8B8B8] border border-[#E8DCC9] dark:border-[#4A4A4A] hover:bg-[#F5E6D3] dark:hover:bg-[#3D3D3D]'
          }`}
        >
          My Items
        </button>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-[#2D2D2D] rounded-lg shadow p-4 border border-[#E8DCC9] dark:border-[#4A4A4A]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-[#B8B8B8] w-5 h-5" />
          <input
            type="text"
            placeholder="Search by equipment name or category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-[#E8DCC9] dark:border-[#4A4A4A] bg-white dark:bg-[#3D3D3D] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8B7355] dark:focus:ring-[#C9A87C]"
          />
        </div>
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item, index) => (
          <div 
            key={item.id} 
            className="bg-white dark:bg-[#2D2D2D] rounded-lg shadow hover:shadow-lg transition-all duration-300 transform hover:scale-105 border border-[#E8DCC9] dark:border-[#4A4A4A] animate-scaleIn"
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="mb-1 text-[#8B7355] dark:text-[#C9A87C]">{item.equipmentName}</h3>
                  <span className="inline-block px-2 py-1 bg-[#F5E6D3] dark:bg-[#3D3D3D] text-[#8B7355] dark:text-[#C9A87C] rounded text-xs">
                    {item.category}
                  </span>
                </div>
              </div>

              <p className="text-gray-600 dark:text-[#B8B8B8] text-sm mb-4">{item.description}</p>

              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B8B8B8]">Condition:</span>
                  <span className="text-gray-900 dark:text-white">{item.condition}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B8B8B8]">Availability:</span>
                  <span className="text-gray-900 dark:text-white">{item.availability}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B8B8B8]">Duration:</span>
                  <span className="text-gray-900 dark:text-white">{item.duration}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E8DCC9] dark:border-[#4A4A4A]">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-[#F5E6D3] dark:bg-[#3D3D3D] rounded-full flex items-center justify-center">
                    <UserIcon className="w-4 h-4 text-[#8B7355] dark:text-[#C9A87C]" />
                  </div>
                  <div className="text-sm">
                    <p className="text-gray-900 dark:text-white">{item.ownerName}</p>
                    <p className="text-gray-500 dark:text-[#B8B8B8] text-xs">{item.postedDate}</p>
                  </div>
                </div>

                {item.ownerName !== user.name && (
                  <button
                    onClick={() => handleContact(item)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-[#8B7355] to-[#A0826D] dark:from-[#C9A87C] dark:to-[#A0826D] text-white rounded-lg hover:shadow-lg transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Contact Owner
                  </button>
                )}
                {item.ownerName === user.name && (
                  <button className="w-full px-4 py-2 bg-[#F5E6D3] dark:bg-[#3D3D3D] text-[#8B7355] dark:text-[#C9A87C] rounded-lg hover:bg-[#E8DCC9] dark:hover:bg-[#4A4A4A] transition-colors">
                    Edit Listing
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="bg-white dark:bg-[#2D2D2D] rounded-lg shadow p-12 text-center text-gray-500 dark:text-[#B8B8B8] border border-[#E8DCC9] dark:border-[#4A4A4A]">
          No shared items found matching your search.
        </div>
      )}

      {/* Add Equipment Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white dark:bg-[#2D2D2D] rounded-lg shadow-xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto border border-[#E8DCC9] dark:border-[#4A4A4A] animate-scaleIn">
            <h2 className="mb-4 text-[#8B7355] dark:text-[#C9A87C]">Share Your Equipment</h2>
            
            <form className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              alert('Equipment shared successfully!');
              setShowAddForm(false);
            }}>
              <div>
                <label className="block text-gray-700 mb-2">Equipment Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Digital Multimeter"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Category</label>
                <select
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select category</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Robotics">Robotics</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Biology">Biology</option>
                  <option value="Physics">Physics</option>
                  <option value="Safety Equipment">Safety Equipment</option>
                  <option value="Books">Books</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Description</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Describe the equipment and its condition..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Condition</label>
                <select
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select condition</option>
                  <option value="New">New</option>
                  <option value="Like New">Like New</option>
                  <option value="Excellent">Excellent</option>
                  <option value="Good">Good</option>
                  <option value="Fair">Fair</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Availability</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Weekends, Mon-Wed"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">Loan Duration</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., 2-3 hours, 1 week"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Share Equipment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}