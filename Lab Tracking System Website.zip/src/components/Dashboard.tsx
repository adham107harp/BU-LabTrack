import { Users, Beaker, AlertCircle, CheckCircle, Package, Share2, FlaskConical, Info, ArrowRight } from 'lucide-react';
import { User } from '../App';

interface DashboardProps {
  user: User;
  onNavigate: (tab: string) => void;
}

export function Dashboard({ user, onNavigate }: DashboardProps) {
  const stats = [
    {
      label: 'Total Lab Rooms',
      value: '12',
      icon: Beaker,
      color: 'bg-gradient-to-br from-[#51829B] to-[#9BB0C1] text-white',
    },
    {
      label: user.role === 'student' ? 'My Reservations' : 'Active Sessions',
      value: user.role === 'student' ? '3' : '8',
      icon: Users,
      color: 'bg-gradient-to-br from-[#F6995C] to-[#51829B] text-white',
    },
    {
      label: 'Available Labs',
      value: '7',
      icon: CheckCircle,
      color: 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300',
    },
    {
      label: user.role === 'student' ? 'Shared Items' : 'Maintenance',
      value: user.role === 'student' ? '5' : '2',
      icon: AlertCircle,
      color: 'bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-300',
    },
  ];

  const navigationCards = [
    {
      icon: Beaker,
      title: 'Lab Rooms',
      description: 'Browse and access laboratory facilities',
      color: 'from-[#51829B] to-[#9BB0C1]',
      tab: 'labs',
    },
    {
      icon: Package,
      title: 'Equipment Reservation',
      description: 'Reserve equipment for your experiments',
      color: 'from-[#9BB0C1] to-[#EADFB4]',
      tab: 'reservation',
    },
    {
      icon: Share2,
      title: 'Equipment Sharing',
      description: 'Share resources with fellow students',
      color: 'from-[#F6995C] to-[#51829B]',
      tab: 'sharing',
    },
    ...(user.role === 'doctor' ? [{
      icon: FlaskConical,
      title: 'Research Lab',
      description: 'Access advanced research facilities',
      color: 'from-[#51829B] to-[#F6995C]',
      tab: 'research',
    }] : []),
    {
      icon: Info,
      title: 'About',
      description: 'Learn more about the system',
      color: 'from-[#9BB0C1] to-[#51829B]',
      tab: 'about',
    },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#51829B] to-[#9BB0C1] dark:from-[#2F3541] dark:to-[#252932] text-white rounded-lg shadow-lg p-6 animate-slideInLeft border-2 border-[#F6995C]">
        <h1 className="text-white mb-2">Welcome back, {user.name}!</h1>
        <p className="text-[#EADFB4] dark:text-[#9BB0C1]">Here's what's happening in your labs today</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div 
            key={index} 
            className="bg-white dark:bg-[#252932] rounded-lg shadow-lg p-6 hover:shadow-xl transition-all duration-300 transform hover:scale-105 animate-scaleIn border-2 border-[#EADFB4] dark:border-[#3A4150]"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 dark:text-[#B0B0B0] text-sm">{stat.label}</p>
                <p className="text-3xl mt-2 text-[#51829B] dark:text-[#9BB0C1]">{stat.value}</p>
              </div>
              <div className={`p-3 rounded-lg shadow-md ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Cards */}
      <div>
        <h2 className="mb-4 text-[#51829B] dark:text-[#9BB0C1]">Navigate</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {navigationCards.map((card, index) => (
            <div
              key={index}
              onClick={() => onNavigate(card.tab)}
              className="group cursor-pointer bg-white dark:bg-[#252932] rounded-lg shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 overflow-hidden animate-scaleIn border-2 border-[#EADFB4] dark:border-[#3A4150]"
              style={{ animationDelay: `${(index + 4) * 0.1}s` }}
            >
              <div className={`h-2 bg-gradient-to-r ${card.color}`}></div>
              <div className="p-6">
                <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r ${card.color} rounded-lg mb-4 shadow-md`}>
                  <card.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="mb-2 text-[#51829B] dark:text-[#9BB0C1]">{card.title}</h3>
                <p className="text-gray-600 dark:text-[#B0B0B0] text-sm mb-4">
                  {card.description}
                </p>
                <div className="flex items-center text-[#F6995C] text-sm group-hover:gap-2 transition-all">
                  <span>Open</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
