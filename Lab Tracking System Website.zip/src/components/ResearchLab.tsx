import { useState } from 'react';
import { Plus, Search, Calendar, Users, AlertTriangle } from 'lucide-react';
import { User } from '../App';

interface ResearchProject {
  id: number;
  title: string;
  principal: string;
  lab: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'pending' | 'completed';
  teamSize: number;
  budget: string;
}

interface AdvancedEquipment {
  id: number;
  name: string;
  model: string;
  lab: string;
  status: 'operational' | 'maintenance' | 'reserved';
  nextMaintenance: string;
  cost: string;
}

interface ResearchLabProps {
  user: User;
}

export function ResearchLab({ user }: ResearchLabProps) {
  const [activeSection, setActiveSection] = useState<'projects' | 'equipment' | 'requests'>('projects');
  const [searchTerm, setSearchTerm] = useState('');

  const [projects] = useState<ResearchProject[]>([
    {
      id: 1,
      title: 'Nanomaterial Synthesis and Characterization',
      principal: 'Dr. Sarah Hassan',
      lab: 'Advanced Materials Lab',
      startDate: '2024-01-15',
      endDate: '2025-01-15',
      status: 'active',
      teamSize: 8,
      budget: '$50,000',
    },
    {
      id: 2,
      title: 'Quantum Computing Algorithm Development',
      principal: 'Dr. Ahmed Khalil',
      lab: 'Quantum Research Lab',
      startDate: '2024-03-01',
      endDate: '2025-03-01',
      status: 'active',
      teamSize: 6,
      budget: '$75,000',
    },
    {
      id: 3,
      title: 'Biomedical Imaging Systems',
      principal: 'Dr. Mona Ibrahim',
      lab: 'Biomedical Engineering Lab',
      startDate: '2024-02-10',
      endDate: '2024-12-31',
      status: 'active',
      teamSize: 10,
      budget: '$120,000',
    },
    {
      id: 4,
      title: 'AI-Powered Drug Discovery',
      principal: 'Dr. Omar Farid',
      lab: 'Computational Biology Lab',
      startDate: '2024-06-01',
      endDate: '2025-06-01',
      status: 'pending',
      teamSize: 5,
      budget: '$90,000',
    },
  ]);

  const [advancedEquipment] = useState<AdvancedEquipment[]>([
    {
      id: 1,
      name: 'Electron Microscope',
      model: 'TEM-5000X',
      lab: 'Advanced Materials Lab',
      status: 'operational',
      nextMaintenance: '2025-01-20',
      cost: '$15/hour',
    },
    {
      id: 2,
      name: 'Mass Spectrometer',
      model: 'MS-Pro 3000',
      lab: 'Chemistry Research Lab',
      status: 'reserved',
      nextMaintenance: '2025-02-15',
      cost: '$20/hour',
    },
    {
      id: 3,
      name: 'X-Ray Diffractometer',
      model: 'XRD-Ultra',
      lab: 'Advanced Materials Lab',
      status: 'operational',
      nextMaintenance: '2025-01-10',
      cost: '$18/hour',
    },
    {
      id: 4,
      name: 'DNA Sequencer',
      model: 'GenSeq-Pro',
      lab: 'Molecular Biology Lab',
      status: 'maintenance',
      nextMaintenance: '2024-12-20',
      cost: '$25/hour',
    },
    {
      id: 5,
      name: 'Atomic Force Microscope',
      model: 'AFM-9000',
      lab: 'Nanotechnology Lab',
      status: 'operational',
      nextMaintenance: '2025-03-01',
      cost: '$22/hour',
    },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'operational':
        return 'bg-green-100 text-green-700';
      case 'pending':
      case 'reserved':
        return 'bg-yellow-100 text-yellow-700';
      case 'completed':
        return 'bg-gray-100 text-gray-700';
      case 'maintenance':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1>Research Laboratory</h1>
          <p className="text-gray-600 mt-1">Manage research projects and advanced equipment</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="w-4 h-4" />
          New Research Project
        </button>
      </div>

      {/* Section Tabs */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveSection('projects')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeSection === 'projects'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Research Projects
          </button>
          <button
            onClick={() => setActiveSection('equipment')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeSection === 'equipment'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Advanced Equipment
          </button>
          <button
            onClick={() => setActiveSection('requests')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeSection === 'requests'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Access Requests
          </button>
        </div>
      </div>

      {/* Research Projects Section */}
      {activeSection === 'projects' && (
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search research projects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {projects.map((project) => (
              <div key={project.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="flex-1">{project.title}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(project.status)}`}>
                      {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                    </span>
                  </div>

                  <div className="space-y-3 mb-4">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span className="text-sm">{project.principal}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-sm">{project.startDate} to {project.endDate}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                    <div>
                      <p className="text-xs text-gray-600">Lab</p>
                      <p className="text-sm">{project.lab}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600">Team Size</p>
                      <p className="text-sm">{project.teamSize} members</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600">Budget</p>
                      <p className="text-sm">{project.budget}</p>
                    </div>
                  </div>

                  <button className="w-full mt-4 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Advanced Equipment Section */}
      {activeSection === 'equipment' && (
        <div className="space-y-6">
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5" />
              <div>
                <p className="text-orange-900">
                  1 equipment item is currently under maintenance
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-gray-600">Equipment</th>
                    <th className="px-6 py-3 text-left text-gray-600">Model</th>
                    <th className="px-6 py-3 text-left text-gray-600">Lab</th>
                    <th className="px-6 py-3 text-left text-gray-600">Status</th>
                    <th className="px-6 py-3 text-left text-gray-600">Next Maintenance</th>
                    <th className="px-6 py-3 text-left text-gray-600">Cost</th>
                    <th className="px-6 py-3 text-left text-gray-600">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {advancedEquipment.map((equipment) => (
                    <tr key={equipment.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">{equipment.name}</td>
                      <td className="px-6 py-4 text-gray-600">{equipment.model}</td>
                      <td className="px-6 py-4 text-gray-600">{equipment.lab}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(equipment.status)}`}>
                          {equipment.status.charAt(0).toUpperCase() + equipment.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-600">{equipment.nextMaintenance}</td>
                      <td className="px-6 py-4">{equipment.cost}</td>
                      <td className="px-6 py-4">
                        <button
                          disabled={equipment.status !== 'operational'}
                          className={`px-3 py-1 rounded text-sm ${
                            equipment.status === 'operational'
                              ? 'bg-blue-600 text-white hover:bg-blue-700'
                              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                          }`}
                        >
                          Book
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Access Requests Section */}
      {activeSection === 'requests' && (
        <div className="bg-white rounded-lg shadow p-8">
          <div className="text-center">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="mb-2">Access Requests</h2>
            <p className="text-gray-600 mb-6">
              Review and approve student requests for research lab access
            </p>
            <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              View Pending Requests
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
