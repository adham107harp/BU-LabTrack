import { useState } from 'react';
import { Beaker, LogIn, Moon, Sun } from 'lucide-react';
import { User, UserRole, useDarkMode } from '../App';

interface LoginProps {
  onLogin: (user: User) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { darkMode, toggleDarkMode } = useDarkMode();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine role based on email
    const role: UserRole = email.includes('doctor') || email.includes('dr.') ? 'doctor' : 'student';
    
    // Mock login - in real app, this would validate credentials
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: role === 'student' ? 'Ahmed Mohamed' : 'Dr. Sarah Hassan',
      email,
      role,
    };
    
    onLogin(user);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAF9F5] via-[#EADFB4] to-[#9BB0C1] dark:from-[#1A1D23] dark:via-[#252932] dark:to-[#1A1D23] flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8 animate-scaleIn">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#51829B] to-[#9BB0C1] dark:from-[#9BB0C1] dark:to-[#51829B] rounded-full mb-4 shadow-lg">
            <Beaker className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-[#51829B] dark:text-[#9BB0C1] mb-2">Badya University</h1>
          <p className="text-gray-600 dark:text-[#B0B0B0]">Laboratory Tracking System</p>
        </div>

        {/* Dark Mode Toggle */}
        <div className="flex justify-center mb-6">
          <button
            onClick={toggleDarkMode}
            className="p-3 bg-white dark:bg-[#252932] rounded-lg shadow-md hover:shadow-lg transition-all duration-300 border-2 border-[#EADFB4] dark:border-[#3A4150]"
          >
            {darkMode ? <Sun className="w-5 h-5 text-[#F6995C]" /> : <Moon className="w-5 h-5 text-[#51829B]" />}
          </button>
        </div>

        {/* Login Form */}
        <div className="bg-white dark:bg-[#252932] rounded-lg shadow-2xl p-8 animate-slideInLeft border-2 border-[#EADFB4] dark:border-[#3A4150]">
          <h2 className="mb-6 text-center text-[#51829B] dark:text-[#9BB0C1]">Sign In</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-gray-700 dark:text-[#B0B0B0] mb-2">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@badya.edu"
                required
                className="w-full px-4 py-3 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1] focus:border-transparent transition-all"
              />
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-gray-700 dark:text-[#B0B0B0] mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                className="w-full px-4 py-3 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1] focus:border-transparent transition-all"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-[#F6995C] to-[#51829B] text-white rounded-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              <LogIn className="w-4 h-4" />
              Sign In
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-600 dark:text-[#B0B0B0]">
            <p>Only Badya's email is working</p>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-gray-600 dark:text-[#B0B0B0] text-sm mt-6">
          Need help? Contact IT Support
        </p>
      </div>
    </div>
  );
}
