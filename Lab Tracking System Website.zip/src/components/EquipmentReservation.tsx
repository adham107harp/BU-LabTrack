import { useState, useEffect } from 'react';
import { Search, Calendar, Clock } from 'lucide-react';
import { User } from '../App';

interface Equipment {
  id: number;
  name: string;
  category: string;
  lab: string;
  available: number;
  total: number;
}

interface Reservation {
  id: number;
  equipmentId: number;
  equipmentName: string;
  date: string;
  startTime: string;
  endTime: string;
  status: 'pending' | 'approved' | 'rejected';
}

interface EquipmentReservationProps {
  user: User;
}

export function EquipmentReservation({ user }: EquipmentReservationProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null);
  const [showReservationForm, setShowReservationForm] = useState(false);
  const [reservationDate, setReservationDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  const [equipment] = useState<Equipment[]>([
    // Computer Lab
    { id: 1, name: 'PC Workstation', category: 'Computer Lab', lab: 'Computer Lab', available: 35, total: 40 },
    { id: 2, name: 'Dual Monitor Setup', category: 'Computer Lab', lab: 'Computer Lab', available: 18, total: 20 },
    { id: 3, name: 'High-Performance PC', category: 'Computer Lab', lab: 'Computer Lab', available: 8, total: 10 },
    { id: 4, name: 'Programming Software License', category: 'Computer Lab', lab: 'Computer Lab', available: 40, total: 40 },
    
    // Physics Lab
    { id: 5, name: 'Oscilloscope', category: 'Physics Lab', lab: 'Physics Lab', available: 10, total: 12 },
    { id: 6, name: 'Multimeter', category: 'Physics Lab', lab: 'Physics Lab', available: 18, total: 20 },
    { id: 7, name: 'Function Generator', category: 'Physics Lab', lab: 'Physics Lab', available: 6, total: 8 },
    { id: 8, name: 'Power Supply Unit', category: 'Physics Lab', lab: 'Physics Lab', available: 13, total: 15 },
    { id: 9, name: 'Experiment Kit A', category: 'Physics Lab', lab: 'Physics Lab', available: 8, total: 10 },
    { id: 10, name: 'Experiment Kit B', category: 'Physics Lab', lab: 'Physics Lab', available: 7, total: 10 },
    
    // Digital Logic Design Lab
    { id: 11, name: 'FPGA Development Board', category: 'Digital Logic', lab: 'Digital Logic Design Lab', available: 16, total: 20 },
    { id: 12, name: 'Logic Analyzer', category: 'Digital Logic', lab: 'Digital Logic Design Lab', available: 8, total: 10 },
    { id: 13, name: 'Breadboard Kit', category: 'Digital Logic', lab: 'Digital Logic Design Lab', available: 25, total: 30 },
    { id: 14, name: 'Arduino Uno', category: 'Digital Logic', lab: 'Digital Logic Design Lab', available: 20, total: 25 },
    { id: 15, name: 'Raspberry Pi 4', category: 'Digital Logic', lab: 'Digital Logic Design Lab', available: 12, total: 15 },
    
    // Chemistry Lab A
    { id: 16, name: 'Bunsen Burner', category: 'Chemistry', lab: 'Chemistry Lab A', available: 5, total: 15 },
    { id: 17, name: 'Beakers (500ml)', category: 'Chemistry', lab: 'Chemistry Lab A', available: 12, total: 30 },
    { id: 18, name: 'pH Meter', category: 'Chemistry', lab: 'Chemistry Lab A', available: 3, total: 10 },
    { id: 19, name: 'Pipettes', category: 'Chemistry', lab: 'Chemistry Lab A', available: 8, total: 25 },
    
    // Biology Lab A
    { id: 20, name: 'Microscope', category: 'Biology', lab: 'Biology Lab A', available: 18, total: 20 },
    { id: 21, name: 'Petri Dishes', category: 'Biology', lab: 'Biology Lab A', available: 85, total: 100 },
    { id: 22, name: 'Centrifuge', category: 'Biology', lab: 'Biology Lab A', available: 6, total: 8 },
    { id: 23, name: 'Incubator', category: 'Biology', lab: 'Biology Lab A', available: 3, total: 4 },
    
    // Robotics Lab
    { id: 24, name: 'Robot Arm Kit', category: 'Robotics', lab: 'Robotics Lab', available: 8, total: 10 },
    { id: 25, name: 'Motor Driver', category: 'Robotics', lab: 'Robotics Lab', available: 16, total: 20 },
    { id: 26, name: '3D Printer', category: 'Robotics', lab: 'Robotics Lab', available: 2, total: 3 },
    { id: 27, name: 'Soldering Station', category: 'Robotics', lab: 'Robotics Lab', available: 8, total: 10 },
    
    // Mechanical Lab
    { id: 28, name: 'CNC Machine', category: 'Mechanical', lab: 'Mechanical Lab', available: 2, total: 2 },
    { id: 29, name: 'Lathe', category: 'Mechanical', lab: 'Mechanical Lab', available: 3, total: 4 },
    { id: 30, name: 'Welding Equipment', category: 'Mechanical', lab: 'Mechanical Lab', available: 5, total: 6 },
    { id: 31, name: 'Drill Press', category: 'Mechanical', lab: 'Mechanical Lab', available: 7, total: 8 },
    
    // Electronics Lab
    { id: 32, name: 'Component Kit', category: 'Electronics', lab: 'Electronics Lab', available: 0, total: 30 },
    { id: 33, name: 'PCB Design Station', category: 'Electronics', lab: 'Electronics Lab', available: 0, total: 15 },
    
    // Chemistry Lab B
    { id: 34, name: 'Spectrophotometer', category: 'Chemistry', lab: 'Chemistry Lab B', available: 4, total: 6 },
    { id: 35, name: 'Fume Hood', category: 'Chemistry', lab: 'Chemistry Lab B', available: 8, total: 8 },
    { id: 36, name: 'Hot Plate', category: 'Chemistry', lab: 'Chemistry Lab B', available: 10, total: 12 },
    
    // Biology Lab B
    { id: 37, name: 'DNA Extraction Kit', category: 'Biology', lab: 'Biology Lab B', available: 12, total: 15 },
    { id: 38, name: 'PCR Machine', category: 'Biology', lab: 'Biology Lab B', available: 2, total: 3 },
    { id: 39, name: 'Gel Electrophoresis Unit', category: 'Biology', lab: 'Biology Lab B', available: 5, total: 6 },
    
    // Data Science Lab
    { id: 40, name: 'High-Performance Workstation', category: 'Data Science', lab: 'Data Science Lab', available: 18, total: 20 },
    { id: 41, name: 'GPU Server Access', category: 'Data Science', lab: 'Data Science Lab', available: 35, total: 35 },
    { id: 42, name: 'Data Analytics Software', category: 'Data Science', lab: 'Data Science Lab', available: 35, total: 35 },
    
    // Materials Lab
    { id: 43, name: 'X-Ray Diffractometer', category: 'Materials', lab: 'Materials Lab', available: 1, total: 1 },
    { id: 44, name: 'SEM Microscope', category: 'Materials', lab: 'Materials Lab', available: 1, total: 1 },
    { id: 45, name: 'Tensile Testing Machine', category: 'Materials', lab: 'Materials Lab', available: 2, total: 2 },
    
    // Research Lab (Doctor only)
    ...(user.role === 'doctor' ? [
      { id: 46, name: 'Mass Spectrometer', category: 'Research', lab: 'Research Lab', available: 2, total: 2 },
      { id: 47, name: 'NMR Spectrometer', category: 'Research', lab: 'Research Lab', available: 1, total: 1 },
      { id: 48, name: 'HPLC System', category: 'Research', lab: 'Research Lab', available: 2, total: 3 },
      { id: 49, name: 'Advanced Microscopy Suite', category: 'Research', lab: 'Research Lab', available: 4, total: 5 },
      { id: 50, name: 'Ultra-Centrifuge', category: 'Research', lab: 'Research Lab', available: 2, total: 2 },
    ] : []),
  ]);

  const [myReservations] = useState<Reservation[]>([
    { id: 1, equipmentId: 20, equipmentName: 'Microscope', date: '2024-12-16', startTime: '10:00', endTime: '12:00', status: 'approved' },
    { id: 2, equipmentId: 5, equipmentName: 'Oscilloscope', date: '2024-12-17', startTime: '14:00', endTime: '16:00', status: 'pending' },
    { id: 3, equipmentId: 34, equipmentName: 'Spectrophotometer', date: '2024-12-18', startTime: '09:00', endTime: '11:00', status: 'approved' },
  ]);

  // Check if equipment was selected from LabRooms
  useEffect(() => {
    const selectedFromLab = localStorage.getItem('selectedEquipment');
    if (selectedFromLab) {
      const equipmentData = JSON.parse(selectedFromLab);
      const matchingEquipment = equipment.find(e => e.name === equipmentData.name);
      if (matchingEquipment) {
        setSelectedEquipment(matchingEquipment);
        setShowReservationForm(true);
      }
      localStorage.removeItem('selectedEquipment');
    }
  }, []);

  const filteredEquipment = equipment.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.lab.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleReserve = (item: Equipment) => {
    setSelectedEquipment(item);
    setShowReservationForm(true);
  };

  const handleSubmitReservation = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Reservation submitted for ${selectedEquipment?.name}!\nDate: ${reservationDate}\nTime: ${startTime} - ${endTime}`);
    setShowReservationForm(false);
    setReservationDate('');
    setStartTime('');
    setEndTime('');
  };

  const getStatusColor = (status: Reservation['status']) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300';
      case 'rejected':
        return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-[#51829B] dark:text-[#9BB0C1]">Equipment Reservation</h1>
        <p className="text-gray-600 dark:text-[#B0B0B0] mt-1">Reserve laboratory equipment for your experiments and projects</p>
      </div>

      {/* My Reservations */}
      <div className="bg-white dark:bg-[#252932] rounded-lg shadow border-2 border-[#EADFB4] dark:border-[#3A4150]">
        <div className="p-6 border-b-2 border-[#EADFB4] dark:border-[#3A4150]">
          <h2 className="text-[#51829B] dark:text-[#9BB0C1]">My Reservations</h2>
        </div>
        <div className="p-6">
          {myReservations.length === 0 ? (
            <p className="text-gray-500 dark:text-[#B0B0B0] text-center py-8">No reservations yet</p>
          ) : (
            <div className="space-y-3">
              {myReservations.map((reservation) => (
                <div key={reservation.id} className="flex items-center justify-between p-4 bg-[#FAF9F5] dark:bg-[#2F3541] rounded-lg border-2 border-[#EADFB4] dark:border-[#3A4150]">
                  <div>
                    <p className="text-gray-900 dark:text-white">{reservation.equipmentName}</p>
                    <div className="flex items-center gap-4 mt-1 text-sm text-gray-600 dark:text-[#B0B0B0]">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {reservation.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {reservation.startTime} - {reservation.endTime}
                      </span>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(reservation.status)}`}>
                    {reservation.status.charAt(0).toUpperCase() + reservation.status.slice(1)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-[#252932] rounded-lg shadow p-4 border-2 border-[#EADFB4] dark:border-[#3A4150]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-[#B0B0B0] w-5 h-5" />
          <input
            type="text"
            placeholder="Search equipment by name, category, or lab..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1]"
          />
        </div>
      </div>

      {/* Equipment Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredEquipment.map((item, index) => (
          <div 
            key={item.id} 
            className="bg-white dark:bg-[#252932] rounded-lg shadow hover:shadow-lg transition-all duration-300 transform hover:scale-105 border-2 border-[#EADFB4] dark:border-[#3A4150] animate-scaleIn"
            style={{ animationDelay: `${index * 0.02}s` }}
          >
            <div className="p-6">
              <h3 className="mb-1 text-[#51829B] dark:text-[#9BB0C1]">{item.name}</h3>
              <p className="text-gray-600 dark:text-[#B0B0B0] text-sm mb-4">{item.category}</p>
              
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B0B0B0]">Lab:</span>
                  <span className="text-gray-900 dark:text-white">{item.lab}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-[#B0B0B0]">Available:</span>
                  <span className={item.available === 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}>
                    {item.available} / {item.total}
                  </span>
                </div>
              </div>

              <button
                onClick={() => handleReserve(item)}
                disabled={item.available === 0}
                className={`w-full px-4 py-2 rounded-lg transition-all ${
                  item.available === 0
                    ? 'bg-gray-200 dark:bg-[#2F3541] text-gray-500 dark:text-[#6B6B6B] cursor-not-allowed'
                    : 'bg-gradient-to-r from-[#F6995C] to-[#51829B] text-white hover:shadow-lg transform hover:scale-105'
                }`}
              >
                {item.available === 0 ? 'Not Available' : 'Reserve'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Reservation Form Modal */}
      {showReservationForm && selectedEquipment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white dark:bg-[#252932] rounded-lg shadow-xl max-w-md w-full p-6 border-2 border-[#F6995C] animate-scaleIn">
            <h2 className="mb-4 text-[#51829B] dark:text-[#9BB0C1]">Reserve {selectedEquipment.name}</h2>
            
            <form onSubmit={handleSubmitReservation} className="space-y-4">
              <div>
                <label className="block text-gray-700 dark:text-[#B0B0B0] mb-2">Date</label>
                <input
                  type="date"
                  value={reservationDate}
                  onChange={(e) => setReservationDate(e.target.value)}
                  required
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-4 py-2 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 dark:text-[#B0B0B0] mb-2">Start Time</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    required
                    className="w-full px-4 py-2 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1]"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 dark:text-[#B0B0B0] mb-2">End Time</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    required
                    className="w-full px-4 py-2 border-2 border-[#EADFB4] dark:border-[#3A4150] bg-white dark:bg-[#2F3541] text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#51829B] dark:focus:ring-[#9BB0C1]"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowReservationForm(false)}
                  className="flex-1 px-4 py-2 bg-gray-200 dark:bg-[#2F3541] text-gray-700 dark:text-[#B0B0B0] rounded-lg hover:bg-gray-300 dark:hover:bg-[#3A4150] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-[#F6995C] to-[#51829B] text-white rounded-lg hover:shadow-lg transition-all"
                >
                  Submit Reservation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}