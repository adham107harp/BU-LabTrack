package com.unilab.dto;

import jakarta.validation.constraints.*;  // ✅ lowercase 'v'
import lombok.Data;

@Data
public class CreateStudentRequest {
    @NotNull(message = "Student ID is required")
    @Min(value = 1000000, message = "Student ID must be at least 7 digits")
    private Integer studentId;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    @Pattern(regexp = ".*@badyauni\\.edu\\.eg$", message = "Email must be @badyauni.edu.eg")
    private String email;
}