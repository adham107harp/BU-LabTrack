package com.unilab.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CreateSharedToolRequest {
    @NotBlank(message = "Tool name is required")
    @Size(min = 2, max = 200, message = "Tool name must be between 2 and 200 characters")
    private String toolName;

    @Size(max = 500, message = "Description must not exceed 500 characters")
    private String description;

    @Size(max = 500, message = "Image URL must not exceed 500 characters")
    private String imageUrl;

    @NotNull(message = "Owner student ID is required")
    private Integer ownerStudentId;
}

