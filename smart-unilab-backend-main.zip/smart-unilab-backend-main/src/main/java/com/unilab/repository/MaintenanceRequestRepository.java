package com.unilab.repository;

public class MaintenanceRequestRepository {
}
