package com.unilab.repository;

import com.unilab.entity.Lab;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LabRepository extends JpaRepository<Lab, Integer> {
    List<Lab> findByLabNameContainingIgnoreCase(String labName);
    List<Lab> findByLocation(String location);
}