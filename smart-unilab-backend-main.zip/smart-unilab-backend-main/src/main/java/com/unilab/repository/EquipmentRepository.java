package com.unilab.repository;

import com.unilab.entity.Equipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EquipmentRepository extends JpaRepository<Equipment, String> {
    List<Equipment> findByStatus(String status);
    List<Equipment> findByLabLabId(Integer labId);
    List<Equipment> findByEquipmentNameContainingIgnoreCase(String name);
}