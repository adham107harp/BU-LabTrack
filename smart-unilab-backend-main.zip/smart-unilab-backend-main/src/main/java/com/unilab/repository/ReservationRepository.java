package com.unilab.repository;

import com.unilab.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Integer> {
    List<Reservation> findByEquipmentEquipmentName(String equipmentName);
    List<Reservation> findByStudentStudentId(Integer studentId);
    List<Reservation> findByDate(LocalDate date);
    List<Reservation> findByEquipmentEquipmentNameAndDate(String equipmentName, LocalDate date);
    List<Reservation> findByStatus(String status);
    List<Reservation> findByEquipmentLabLabId(Integer labId);
    List<Reservation> findByEquipmentLabLabIdAndDate(Integer labId, LocalDate date);
}