package com.unilab.repository;

import com.unilab.entity.LabSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface LabScheduleRepository extends JpaRepository<LabSchedule, Long> {
    List<LabSchedule> findByLabLabId(Integer labId);
    
    @Query("SELECT ls FROM LabSchedule ls WHERE ls.lab.labId = :labId AND ls.day = :day")
    List<LabSchedule> findByLabAndDay(@Param("labId") Integer labId, @Param("day") String day);
    
    @Query("SELECT ls FROM LabSchedule ls WHERE ls.lab.labId = :labId AND ls.day = :day AND :time BETWEEN ls.startTime AND ls.endTime")
    Optional<LabSchedule> findActiveSession(@Param("labId") Integer labId, @Param("day") String day, @Param("time") LocalTime time);
}

