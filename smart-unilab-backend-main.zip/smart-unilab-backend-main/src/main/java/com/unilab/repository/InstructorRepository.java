package com.unilab.repository;

import com.unilab.entity.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface InstructorRepository extends JpaRepository<Instructor, Integer> {
    Optional<Instructor> findByEmail(String email);
    List<Instructor> findByNameContainingIgnoreCase(String name);
    boolean existsByEmail(String email);
}