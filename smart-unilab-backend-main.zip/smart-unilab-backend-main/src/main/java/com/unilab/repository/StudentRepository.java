package com.unilab.repository;

import com.unilab.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
    Optional<Student> findByEmail(String email);
    List<Student> findByNameContainingIgnoreCase(String name);

    // FIXED QUERY: Search by studentId, name, or email
    @Query("SELECT s FROM Student s WHERE CAST(s.studentId AS string) LIKE CONCAT('%', :keyword, '%') OR LOWER(s.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(s.email) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Student> searchStudents(@Param("keyword") String keyword);

    boolean existsByEmail(String email);
    
    // Find distinct students who have reservations for equipment in a specific lab
    @Query("SELECT DISTINCT s FROM Student s JOIN s.reservations r WHERE r.equipment.lab.labId = :labId")
    List<Student> findDistinctByReservationsLabLabId(@Param("labId") Integer labId);
}