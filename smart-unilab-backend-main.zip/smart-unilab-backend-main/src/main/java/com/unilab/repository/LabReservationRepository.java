package com.unilab.repository;

import com.unilab.entity.LabReservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface LabReservationRepository extends JpaRepository<LabReservation, Integer> {
    List<LabReservation> findByLabLabId(Integer labId);
    List<LabReservation> findByInstructorInstructorId(Integer instructorId);
    List<LabReservation> findByDate(LocalDate date);
    List<LabReservation> findByLabLabIdAndDate(Integer labId, LocalDate date);
    List<LabReservation> findByStatus(String status);
    List<LabReservation> findByLabLabIdAndDateAndStatus(Integer labId, LocalDate date, String status);
}

