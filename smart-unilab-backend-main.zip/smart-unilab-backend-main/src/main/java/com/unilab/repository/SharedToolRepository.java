package com.unilab.repository;

import com.unilab.entity.SharedTool;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SharedToolRepository extends JpaRepository<SharedTool, Integer> {
    List<SharedTool> findByOwnerStudentId(Integer studentId);
    List<SharedTool> findByToolNameContainingIgnoreCase(String keyword);
    List<SharedTool> findByContactEmail(String email);
}

