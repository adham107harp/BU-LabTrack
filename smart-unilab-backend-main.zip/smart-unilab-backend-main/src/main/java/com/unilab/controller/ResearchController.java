package com.unilab.controller;

import com.unilab.entity.Research;
import com.unilab.service.ResearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/research")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://localhost:8080"})
public class ResearchController {

    @Autowired
    private ResearchService researchService;

    @PostMapping
    public ResponseEntity<Research> createResearch(@RequestBody Research research) {
        Research created = researchService.createResearch(research);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Research> getResearch(@PathVariable Integer id) {
        Research research = researchService.getResearchById(id);
        return ResponseEntity.ok(research);
    }

    @GetMapping
    public ResponseEntity<List<Research>> getAllResearch() {
        List<Research> research = researchService.getAllResearch();
        return ResponseEntity.ok(research);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Research> updateResearch(@PathVariable Integer id, @RequestBody Research research) {
        Research updated = researchService.updateResearch(id, research);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteResearch(@PathVariable Integer id) {
        researchService.deleteResearch(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/lab/{labId}")
    public ResponseEntity<List<Research>> getResearchByLab(@PathVariable Integer labId) {
        List<Research> research = researchService.getResearchByLab(labId);
        return ResponseEntity.ok(research);
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Research>> getResearchByStudent(@PathVariable Integer studentId) {
        List<Research> research = researchService.getResearchByStudent(studentId);
        return ResponseEntity.ok(research);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Research>> searchResearch(@RequestParam String keyword) {
        List<Research> research = researchService.searchResearch(keyword);
        return ResponseEntity.ok(research);
    }
}

