package com.unilab.controller;

import com.unilab.entity.Lab;
import com.unilab.service.LabService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/labs")
public class LabController {

    @Autowired
    private LabService labService;

    @PostMapping
    public ResponseEntity<Lab> createLab(@RequestBody Lab lab) {
        Lab created = labService.createLab(lab);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Lab> getLab(@PathVariable Integer id) {
        Lab lab = labService.getLabById(id);
        return ResponseEntity.ok(lab);
    }

    @GetMapping
    public ResponseEntity<List<Lab>> getAllLabs() {
        List<Lab> labs = labService.getAllLabs();
        return ResponseEntity.ok(labs);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Lab> updateLab(@PathVariable Integer id, @RequestBody Lab lab) {
        Lab updated = labService.updateLab(id, lab);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLab(@PathVariable Integer id) {
        labService.deleteLab(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<Lab>> searchLabs(@RequestParam String keyword) {
        List<Lab> labs = labService.searchLabs(keyword);
        return ResponseEntity.ok(labs);
    }

    @GetMapping("/location/{location}")
    public ResponseEntity<List<Lab>> getLabsByLocation(@PathVariable String location) {
        List<Lab> labs = labService.getLabsByLocation(location);
        return ResponseEntity.ok(labs);
    }

    @GetMapping("/available")
    public ResponseEntity<List<Lab>> getAvailableLabs() {
        List<Lab> labs = labService.getAvailableLabs();
        return ResponseEntity.ok(labs);
    }
}