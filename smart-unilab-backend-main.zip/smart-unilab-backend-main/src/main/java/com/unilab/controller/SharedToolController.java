package com.unilab.controller;

import com.unilab.dto.CreateSharedToolRequest;
import com.unilab.entity.SharedTool;
import com.unilab.entity.Student;
import com.unilab.service.SharedToolService;
import com.unilab.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/shared-tools")
public class SharedToolController {

    @Autowired
    private SharedToolService sharedToolService;

    @Autowired
    private StudentService studentService;

    @PostMapping
    public ResponseEntity<SharedTool> createTool(@Valid @RequestBody CreateSharedToolRequest request) {
        Student owner = studentService.getStudentById(request.getOwnerStudentId());
        
        SharedTool tool = new SharedTool();
        tool.setToolName(request.getToolName());
        tool.setDescription(request.getDescription());
        tool.setImageUrl(request.getImageUrl());
        tool.setOwner(owner);
        tool.setContactEmail(owner.getEmail()); // Use owner's university email
        
        SharedTool created = sharedToolService.createTool(tool);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SharedTool> getTool(@PathVariable Integer id) {
        SharedTool tool = sharedToolService.getToolById(id);
        return ResponseEntity.ok(tool);
    }

    @GetMapping
    public ResponseEntity<List<SharedTool>> getAllTools() {
        List<SharedTool> tools = sharedToolService.getAllTools();
        return ResponseEntity.ok(tools);
    }

    @GetMapping("/owner/{studentId}")
    public ResponseEntity<List<SharedTool>> getToolsByOwner(@PathVariable Integer studentId) {
        List<SharedTool> tools = sharedToolService.getToolsByOwner(studentId);
        return ResponseEntity.ok(tools);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SharedTool> updateTool(
            @PathVariable Integer id,
            @Valid @RequestBody CreateSharedToolRequest request) {
        Student owner = studentService.getStudentById(request.getOwnerStudentId());
        
        SharedTool tool = new SharedTool();
        tool.setToolName(request.getToolName());
        tool.setDescription(request.getDescription());
        tool.setImageUrl(request.getImageUrl());
        tool.setOwner(owner);
        tool.setContactEmail(owner.getEmail());
        
        SharedTool updated = sharedToolService.updateTool(id, tool);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTool(
            @PathVariable Integer id,
            @RequestParam Integer ownerStudentId) {
        sharedToolService.deleteTool(id, ownerStudentId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<SharedTool>> searchTools(@RequestParam String keyword) {
        List<SharedTool> tools = sharedToolService.searchTools(keyword);
        return ResponseEntity.ok(tools);
    }
}

