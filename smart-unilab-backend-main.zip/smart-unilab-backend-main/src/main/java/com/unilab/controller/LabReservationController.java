package com.unilab.controller;

import com.unilab.entity.LabReservation;
import com.unilab.service.LabReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/lab-reservations")
public class LabReservationController {

    @Autowired
    private LabReservationService labReservationService;

    @PostMapping
    public ResponseEntity<LabReservation> createLabReservation(@RequestBody LabReservation labReservation) {
        LabReservation created = labReservationService.createLabReservation(labReservation);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LabReservation> getLabReservation(@PathVariable Integer id) {
        LabReservation reservation = labReservationService.getLabReservationById(id);
        return ResponseEntity.ok(reservation);
    }

    @GetMapping
    public ResponseEntity<List<LabReservation>> getAllLabReservations() {
        List<LabReservation> reservations = labReservationService.getAllLabReservations();
        return ResponseEntity.ok(reservations);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LabReservation> updateLabReservation(@PathVariable Integer id, @RequestBody LabReservation labReservation) {
        LabReservation updated = labReservationService.updateLabReservation(id, labReservation);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLabReservation(@PathVariable Integer id) {
        labReservationService.deleteLabReservation(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/lab/{labId}")
    public ResponseEntity<List<LabReservation>> getLabReservationsByLab(@PathVariable Integer labId) {
        List<LabReservation> reservations = labReservationService.getLabReservationsByLab(labId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/instructor/{instructorId}")
    public ResponseEntity<List<LabReservation>> getLabReservationsByInstructor(@PathVariable Integer instructorId) {
        List<LabReservation> reservations = labReservationService.getLabReservationsByInstructor(instructorId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/date/{date}")
    public ResponseEntity<List<LabReservation>> getLabReservationsByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<LabReservation> reservations = labReservationService.getLabReservationsByDate(date);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/pending")
    public ResponseEntity<List<LabReservation>> getPendingLabReservations() {
        List<LabReservation> reservations = labReservationService.getPendingLabReservations();
        return ResponseEntity.ok(reservations);
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<LabReservation> approveLabReservation(@PathVariable Integer id) {
        LabReservation approved = labReservationService.approveLabReservation(id);
        return ResponseEntity.ok(approved);
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<LabReservation> rejectLabReservation(@PathVariable Integer id) {
        LabReservation rejected = labReservationService.rejectLabReservation(id);
        return ResponseEntity.ok(rejected);
    }

    @GetMapping("/check-availability")
    public ResponseEntity<Boolean> checkLabAvailability(
            @RequestParam Integer labId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam String startTime,
            @RequestParam String endTime) {
        boolean isAvailable = labReservationService.checkLabAvailability(labId, date, startTime, endTime);
        return ResponseEntity.ok(isAvailable);
    }
}

