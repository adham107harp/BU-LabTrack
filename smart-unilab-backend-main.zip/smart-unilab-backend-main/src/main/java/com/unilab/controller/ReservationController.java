package com.unilab.controller;

import com.unilab.entity.Reservation;
import com.unilab.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @PostMapping
    public ResponseEntity<Reservation> createReservation(@RequestBody Reservation reservation) {
        Reservation created = reservationService.createReservation(reservation);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reservation> getReservation(@PathVariable Integer id) {
        Reservation reservation = reservationService.getReservationById(id);
        return ResponseEntity.ok(reservation);
    }

    @GetMapping
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.getAllReservations();
        return ResponseEntity.ok(reservations);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reservation> updateReservation(@PathVariable Integer id, @RequestBody Reservation reservation) {
        Reservation updated = reservationService.updateReservation(id, reservation);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReservation(@PathVariable Integer id) {
        reservationService.deleteReservation(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/equipment/{equipmentName}")
    public ResponseEntity<List<Reservation>> getReservationsByEquipment(@PathVariable String equipmentName) {
        List<Reservation> reservations = reservationService.getReservationsByEquipment(equipmentName);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/lab/{labId}")
    public ResponseEntity<List<Reservation>> getReservationsByLab(@PathVariable Integer labId) {
        List<Reservation> reservations = reservationService.getReservationsByLab(labId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Reservation>> getReservationsByStudent(@PathVariable Integer studentId) {
        List<Reservation> reservations = reservationService.getReservationsByStudent(studentId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/date/{date}")
    public ResponseEntity<List<Reservation>> getReservationsByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<Reservation> reservations = reservationService.getReservationsByDate(date);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/pending")
    public ResponseEntity<List<Reservation>> getPendingReservations() {
        List<Reservation> reservations = reservationService.getPendingReservations();
        return ResponseEntity.ok(reservations);
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<Reservation> approveReservation(@PathVariable Integer id) {
        Reservation approved = reservationService.approveReservation(id);
        return ResponseEntity.ok(approved);
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<Reservation> rejectReservation(@PathVariable Integer id) {
        Reservation rejected = reservationService.rejectReservation(id);
        return ResponseEntity.ok(rejected);
    }

    @GetMapping("/check-availability")
    public ResponseEntity<Boolean> checkEquipmentAvailability(
            @RequestParam String equipmentName,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam String startTime,
            @RequestParam String endTime) {
        boolean isAvailable = reservationService.checkEquipmentAvailability(equipmentName, date, startTime, endTime);
        return ResponseEntity.ok(isAvailable);
    }
}
