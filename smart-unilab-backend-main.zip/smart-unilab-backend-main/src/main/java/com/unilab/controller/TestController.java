package com.unilab.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/test")
// REMOVE: @CrossOrigin("*") - Let CorsConfig handle it
public class TestController {

    @GetMapping("/hello")
    public String hello() {
        return "🚀 Smart UniLab Backend is Running!";
    }

    @GetMapping("/status")
    public String status() {
        return """
               ✅ Backend Status: ACTIVE
               📅 Database: Connected
               🔧 Spring Boot: 3.4.12
               📍 Port: 8080
               """;
    }
}