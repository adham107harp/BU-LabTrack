package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "shared_tool")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SharedTool {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ToolID")
    private Integer toolId;

    @Column(name = "ToolName", length = 200, nullable = false)
    private String toolName;

    @Column(name = "Description", length = 500)
    private String description;

    @Column(name = "ImageURL", length = 500)
    private String imageUrl;

    @ManyToOne
    @JoinColumn(name = "OwnerStudentID", nullable = false)
    private Student owner;

    @Column(name = "ContactEmail", length = 100, nullable = false)
    private String contactEmail; // University email for contact

    // Custom constructor for creating tools
    public SharedTool(String toolName, String description, String imageUrl, Student owner, String contactEmail) {
        this.toolName = toolName;
        this.description = description;
        this.imageUrl = imageUrl;
        this.owner = owner;
        this.contactEmail = contactEmail;
    }
}

