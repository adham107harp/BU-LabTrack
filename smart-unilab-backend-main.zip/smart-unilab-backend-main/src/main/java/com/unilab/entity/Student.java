package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "student")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
    @Id
    @Column(name = "StudentID")
    private Integer studentId;

    @Column(name = "Name", length = 100)
    private String name;

    @Column(name = "Email", length = 100, unique = true)
    private String email;

    @Column(name = "Password", length = 255)
    @JsonIgnore
    private String password;

    @JsonIgnore
    @OneToMany(mappedBy = "student")
    private List<Reservation> reservations;

    @JsonIgnore
    @OneToMany(mappedBy = "student")
    private List<Research> researchProjects;

    @JsonIgnore
    @OneToMany(mappedBy = "student")
    private List<TeamMember> teamMemberships;

    // Custom constructor for seeding data
    public Student(Integer studentId, String name, String email) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
    }

    // Custom constructor with password
    public Student(Integer studentId, String name, String email, String password) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.password = password;
    }
}