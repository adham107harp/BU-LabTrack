package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "teammember")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeamMember {
    @Id
    @Column(name = "TeamMemberID")
    private Integer teamMemberId;

    @ManyToOne
    @JoinColumn(name = "ReservationID")
    private Reservation reservation;

    @ManyToOne
    @JoinColumn(name = "StudentID")
    private Student student;
}