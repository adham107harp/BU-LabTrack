package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "equipment")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Equipment {
    @Id
    @Column(name = "EquipmentName", length = 100)
    private String equipmentName;

    @Column(name = "Status", length = 20)
    private String status;

    @ManyToOne
    @JoinColumn(name = "LabID")
    private Lab lab;

    @JsonIgnore
    @OneToMany(mappedBy = "equipment")
    private List<Reservation> reservations;

    // Custom constructor for seeding data
    public Equipment(String equipmentName, String status, Lab lab) {
        this.equipmentName = equipmentName;
        this.status = status;
        this.lab = lab;
    }
}