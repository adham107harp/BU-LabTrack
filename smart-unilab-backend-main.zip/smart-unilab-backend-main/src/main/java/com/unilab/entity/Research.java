package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "research")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Research {
    @Id
    @Column(name = "ResearchID")
    private Integer researchId;

    @ManyToOne
    @JoinColumn(name = "LabID")
    private Lab lab;

    @ManyToOne
    @JoinColumn(name = "StudentID")
    private Student student;

    @Column(name = "Title", length = 200)
    private String title;

    @Column(name = "StartDate")
    private LocalDate startDate;

    @Column(name = "EndDate")
    private LocalDate endDate;
}