package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "lab_reservation")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LabReservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LabReservationID")
    private Integer labReservationId;

    @ManyToOne
    @JoinColumn(name = "LabID", nullable = false)
    private Lab lab;

    @ManyToOne
    @JoinColumn(name = "InstructorID", nullable = false)
    private Instructor instructor;

    @Column(name = "Date", nullable = false)
    private LocalDate date;

    @Column(name = "StartTime", nullable = false)
    private LocalTime startTime;

    @Column(name = "EndTime", nullable = false)
    private LocalTime endTime;

    @Column(name = "Purpose", length = 200)
    private String purpose;

    @Column(name = "Status", length = 20)
    private String status = "PENDING"; // PENDING, APPROVED, REJECTED

    @Column(name = "ResearchID")
    private Integer researchId; // Optional link to research project
}

