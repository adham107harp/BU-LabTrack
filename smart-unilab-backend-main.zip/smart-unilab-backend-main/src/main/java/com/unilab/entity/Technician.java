package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "technician")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Technician {
    @Id
    @Column(name = "TechnicianID")
    private Integer technicianId;

    @Column(name = "Name", length = 100)
    private String name;

    @Column(name = "Specialization", length = 50)
    private String specialization;

    @JsonIgnore
    @OneToMany(mappedBy = "technician")
    private List<MaintenanceRequest> maintenanceRequests;

    // Custom constructor for seeding data
    public Technician(Integer technicianId, String name, String specialization) {
        this.technicianId = technicianId;
        this.name = name;
        this.specialization = specialization;
    }
}