package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "lab")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Lab {
    @Id
    @Column(name = "LabID")
    private Integer labId;

    @Column(name = "LabName", length = 100)
    private String labName;

    @Column(name = "Location", length = 100)
    private String location;

    @Column(name = "Capacity")
    private Integer capacity;

    @Column(name = "RequiredLevel")
    private Integer requiredLevel = 2500;

    @ManyToOne
    @JoinColumn(name = "InstructorEmail", referencedColumnName = "InstructorEmail")
    private Instructor instructor;

    @JsonIgnore
    @OneToMany(mappedBy = "lab")
    private List<Equipment> equipmentList;

    @JsonIgnore
    @OneToMany(mappedBy = "lab")
    private List<LabSchedule> schedules;

    // Reservations are now linked to Equipment, not Lab directly
    // To get reservations for a lab, query by equipment in that lab

    @JsonIgnore
    @OneToMany(mappedBy = "lab")
    private List<Research> researchProjects;

    // Custom constructor for seeding data
    public Lab(Integer labId, String labName, String location, Integer capacity, Instructor instructor, Integer requiredLevel) {
        this.labId = labId;
        this.labName = labName;
        this.location = location;
        this.capacity = capacity;
        this.instructor = instructor;
        this.requiredLevel = requiredLevel;
    }
}