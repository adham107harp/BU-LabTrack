package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "reservation")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reservation {
    @Id
    @Column(name = "ReservationID")
    private Integer reservationId;

    @ManyToOne
    @JoinColumn(name = "EquipmentName")
    private Equipment equipment;

    @ManyToOne
    @JoinColumn(name = "StudentID")
    private Student student;

    @ManyToOne
    @JoinColumn(name = "SupervisorID")
    private Instructor supervisor;

    @Column(name = "Date")
    private LocalDate date;

    @Column(name = "Time")
    private LocalTime time;

    @Column(name = "Duration")
    private Integer duration;

    @Column(name = "Purpose", length = 200)
    private String purpose;

    @Column(name = "ReservationType", length = 20)
    private String reservationType;

    @Column(name = "TeamSize")
    private Integer teamSize;

    @Column(name = "Status", length = 20)
    private String status = "PENDING"; // PENDING, APPROVED, REJECTED
}