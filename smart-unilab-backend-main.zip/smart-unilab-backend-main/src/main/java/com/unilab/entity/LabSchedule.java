package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalTime;

@Entity
@Table(name = "labschedule")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LabSchedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "LabID")
    private Lab lab;

    @Column(name = "\"Day\"")  // Use quotes for reserved keyword
    private String day;

    @Column(name = "StartTime")
    private LocalTime startTime;

    @Column(name = "EndTime")
    private LocalTime endTime;
}