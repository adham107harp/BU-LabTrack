package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "instructor")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Instructor {
    @Id
    @Column(name = "InstructorID")
    private Integer instructorId;

    @Column(name = "Name", length = 100)
    private String name;

    @Column(name = "InstructorEmail", length = 100, unique = true)
    private String email;

    @JsonIgnore
    @OneToMany(mappedBy = "instructor")
    private List<Lab> labs;

    @JsonIgnore
    @OneToMany(mappedBy = "supervisor")
    private List<Reservation> supervisedReservations;

    // Custom constructor for seeding data
    public Instructor(Integer instructorId, String name, String email) {
        this.instructorId = instructorId;
        this.name = name;
        this.email = email;
    }
}