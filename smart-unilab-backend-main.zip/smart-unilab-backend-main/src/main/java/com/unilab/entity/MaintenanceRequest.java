package com.unilab.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "maintenancerequest")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaintenanceRequest {
    @Id
    @Column(name = "MaintenanceID")
    private Integer maintenanceId;

    @ManyToOne
    @JoinColumn(name = "TechnicianID")
    private Technician technician;

    @ManyToOne
    @JoinColumn(name = "EquipmentName")
    private Equipment equipment;

    @Column(name = "RequestDate")
    private LocalDate requestDate;

    @Column(name = "Status", length = 20)
    private String status;

    @Column(name = "Description", columnDefinition = "TEXT")
    private String description;
}