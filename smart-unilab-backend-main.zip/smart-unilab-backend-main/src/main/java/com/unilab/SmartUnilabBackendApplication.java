package com.unilab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartUnilabBackendApplication {
	public static void main(String[] args) {
		SpringApplication.run(SmartUnilabBackendApplication.class, args);
		System.out.println("✅ Smart UniLab Backend Started!");
		System.out.println("🌐 Server: http://localhost:8080");
		System.out.println("📚 API Docs: http://localhost:8080/swagger-ui.html");
	}
}