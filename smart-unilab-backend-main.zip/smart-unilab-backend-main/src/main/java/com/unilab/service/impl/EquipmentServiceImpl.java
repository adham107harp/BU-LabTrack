package com.unilab.service.impl;

import com.unilab.entity.Equipment;
import com.unilab.repository.EquipmentRepository;
import com.unilab.service.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class EquipmentServiceImpl implements EquipmentService {

    @Autowired
    private EquipmentRepository equipmentRepository;

    @Override
    public Equipment createEquipment(Equipment equipment) {
        return equipmentRepository.save(equipment);
    }

    @Override
    public Equipment getEquipmentByName(String name) {
        return equipmentRepository.findById(name)
                .orElseThrow(() -> new RuntimeException("Equipment not found: " + name));
    }

    @Override
    public List<Equipment> getAllEquipment() {
        return equipmentRepository.findAll();
    }

    @Override
    public Equipment updateEquipment(String name, Equipment equipment) {
        Equipment existingEquipment = getEquipmentByName(name);
        existingEquipment.setStatus(equipment.getStatus());
        existingEquipment.setLab(equipment.getLab());
        return equipmentRepository.save(existingEquipment);
    }

    @Override
    public void deleteEquipment(String name) {
        if (!equipmentRepository.existsById(name)) {
            throw new RuntimeException("Equipment not found: " + name);
        }
        equipmentRepository.deleteById(name);
    }

    @Override
    public List<Equipment> getEquipmentByLab(Integer labId) {
        return equipmentRepository.findByLabLabId(labId);
    }

    @Override
    public List<Equipment> getEquipmentByStatus(String status) {
        return equipmentRepository.findByStatus(status);
    }

    @Override
    public Equipment updateEquipmentStatus(String name, String status) {
        Equipment equipment = getEquipmentByName(name);
        equipment.setStatus(status);
        return equipmentRepository.save(equipment);
    }

    @Override
    public List<Equipment> searchEquipment(String keyword) {
        return equipmentRepository.findByEquipmentNameContainingIgnoreCase(keyword);
    }
}