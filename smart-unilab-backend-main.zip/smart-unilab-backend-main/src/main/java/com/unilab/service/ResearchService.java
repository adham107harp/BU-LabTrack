package com.unilab.service;

import com.unilab.entity.Research;
import java.util.List;

public interface ResearchService {
    Research createResearch(Research research);
    Research getResearchById(Integer id);
    List<Research> getAllResearch();
    Research updateResearch(Integer id, Research research);
    void deleteResearch(Integer id);
    List<Research> getResearchByLab(Integer labId);
    List<Research> getResearchByStudent(Integer studentId);
    List<Research> searchResearch(String keyword);
}

