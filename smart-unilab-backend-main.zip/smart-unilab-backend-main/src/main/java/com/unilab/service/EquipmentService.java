package com.unilab.service;

import com.unilab.entity.Equipment;
import java.util.List;

public interface EquipmentService {
    Equipment createEquipment(Equipment equipment);
    Equipment getEquipmentByName(String name);
    List<Equipment> getAllEquipment();
    Equipment updateEquipment(String name, Equipment equipment);
    void deleteEquipment(String name);
    List<Equipment> getEquipmentByLab(Integer labId);
    List<Equipment> getEquipmentByStatus(String status);
    Equipment updateEquipmentStatus(String name, String status);
    List<Equipment> searchEquipment(String keyword);
}