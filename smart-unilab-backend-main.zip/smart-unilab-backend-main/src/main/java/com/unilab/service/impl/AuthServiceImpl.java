package com.unilab.service.impl;

import com.unilab.dto.AuthResponse;
import com.unilab.dto.LoginRequest;
import com.unilab.dto.RegisterRequest;
import com.unilab.entity.Student;
import com.unilab.repository.StudentRepository;
import com.unilab.service.AuthService;
import com.unilab.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AuthServiceImpl implements AuthService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public AuthResponse register(RegisterRequest request) {
        // Step 1: Validate Student ID exists in database
        Student existingStudent = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new RuntimeException("Student ID not found. Please verify your Student ID."));

        // Step 2: Validate Name matches the Student ID
        if (!existingStudent.getName().equalsIgnoreCase(request.getName().trim())) {
            throw new RuntimeException("Name does not match Student ID. Please verify your name.");
        }

        // Step 3: Validate Email matches the Student ID
        if (!existingStudent.getEmail().equalsIgnoreCase(request.getEmail().trim())) {
            throw new RuntimeException("Email does not match Student ID. Please verify your email.");
        }

        // Step 4: Check if account already exists (password is set)
        if (existingStudent.getPassword() != null && !existingStudent.getPassword().isEmpty()) {
            throw new RuntimeException("Account already exists. Please login instead.");
        }

        // Step 5: Set password for the existing student
        existingStudent.setPassword(passwordEncoder.encode(request.getPassword()));

        Student savedStudent = studentRepository.save(existingStudent);

        // Generate JWT token
        String role = determineRole(savedStudent.getEmail());
        String token = jwtUtil.generateToken(savedStudent.getStudentId(), savedStudent.getEmail(), role);

        return new AuthResponse(
            token,
            savedStudent.getStudentId(),
            savedStudent.getName(),
            savedStudent.getEmail(),
            role,
            "Registration successful"
        );
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        // Find student by email
        Student student = studentRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        // Verify password
        if (!passwordEncoder.matches(request.getPassword(), student.getPassword())) {
            throw new RuntimeException("Invalid email or password");
        }

        // Generate JWT token
        String role = determineRole(student.getEmail());
        String token = jwtUtil.generateToken(student.getStudentId(), student.getEmail(), role);

        return new AuthResponse(
            token,
            student.getStudentId(),
            student.getName(),
            student.getEmail(),
            role,
            "Login successful"
        );
    }

    private String determineRole(String email) {
        // Determine role based on email
        if (email.contains("doctor") || email.contains("dr.") || email.contains("prof.")) {
            return "doctor";
        }
        return "student";
    }
}

