package com.unilab.service.impl;

import com.unilab.entity.LabSchedule;
import com.unilab.repository.LabScheduleRepository;
import com.unilab.service.LabScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

@Service
@Transactional
public class LabScheduleServiceImpl implements LabScheduleService {

    // School day hours: 8:00 AM to 6:00 PM
    private static final LocalTime SCHOOL_DAY_START = LocalTime.of(8, 0);
    private static final LocalTime SCHOOL_DAY_END = LocalTime.of(18, 0);

    @Autowired
    private LabScheduleRepository labScheduleRepository;

    @Override
    public List<LabSchedule> getSchedulesByLab(Integer labId) {
        return labScheduleRepository.findByLabLabId(labId);
    }

    @Override
    public List<LabSchedule> getSchedulesByLabAndDay(Integer labId, String day) {
        return labScheduleRepository.findByLabAndDay(labId, day);
    }

    @Override
    public boolean isLabInSession(Integer labId, String day, LocalTime time) {
        return labScheduleRepository.findActiveSession(labId, day, time).isPresent();
    }

    @Override
    public boolean isWithinSchoolHours(LocalTime time) {
        return !time.isBefore(SCHOOL_DAY_START) && !time.isAfter(SCHOOL_DAY_END);
    }

    @Override
    public String getDayOfWeekName(DayOfWeek dayOfWeek) {
        switch (dayOfWeek) {
            case MONDAY: return "Monday";
            case TUESDAY: return "Tuesday";
            case WEDNESDAY: return "Wednesday";
            case THURSDAY: return "Thursday";
            case FRIDAY: return "Friday";
            case SATURDAY: return "Saturday";
            case SUNDAY: return "Sunday";
            default: return dayOfWeek.toString();
        }
    }
}

