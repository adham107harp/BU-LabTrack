package com.unilab.service;

import com.unilab.entity.LabSchedule;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

public interface LabScheduleService {
    List<LabSchedule> getSchedulesByLab(Integer labId);
    List<LabSchedule> getSchedulesByLabAndDay(Integer labId, String day);
    boolean isLabInSession(Integer labId, String day, LocalTime time);
    boolean isWithinSchoolHours(LocalTime time);
    String getDayOfWeekName(DayOfWeek dayOfWeek);
}

