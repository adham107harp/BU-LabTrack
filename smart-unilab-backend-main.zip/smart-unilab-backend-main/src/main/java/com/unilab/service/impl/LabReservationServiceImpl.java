package com.unilab.service.impl;

import com.unilab.entity.LabReservation;
import com.unilab.repository.LabReservationRepository;
import com.unilab.service.LabReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@Transactional
public class LabReservationServiceImpl implements LabReservationService {

    @Autowired
    private LabReservationRepository labReservationRepository;

    @Override
    public LabReservation createLabReservation(LabReservation labReservation) {
        // Set status to PENDING (requires admin approval)
        labReservation.setStatus("PENDING");
        
        // Check lab availability
        if (!checkLabAvailability(
                labReservation.getLab().getLabId(),
                labReservation.getDate(),
                labReservation.getStartTime().toString(),
                labReservation.getEndTime().toString())) {
            throw new RuntimeException("Lab is not available at the requested time. There is a conflict with an existing approved reservation.");
        }
        
        return labReservationRepository.save(labReservation);
    }

    @Override
    public LabReservation getLabReservationById(Integer id) {
        return labReservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lab reservation not found with ID: " + id));
    }

    @Override
    public List<LabReservation> getAllLabReservations() {
        return labReservationRepository.findAll();
    }

    @Override
    public LabReservation updateLabReservation(Integer id, LabReservation labReservation) {
        LabReservation existing = getLabReservationById(id);
        existing.setLab(labReservation.getLab());
        existing.setInstructor(labReservation.getInstructor());
        existing.setDate(labReservation.getDate());
        existing.setStartTime(labReservation.getStartTime());
        existing.setEndTime(labReservation.getEndTime());
        existing.setPurpose(labReservation.getPurpose());
        existing.setResearchId(labReservation.getResearchId());
        return labReservationRepository.save(existing);
    }

    @Override
    public void deleteLabReservation(Integer id) {
        if (!labReservationRepository.existsById(id)) {
            throw new RuntimeException("Lab reservation not found with ID: " + id);
        }
        labReservationRepository.deleteById(id);
    }

    @Override
    public List<LabReservation> getLabReservationsByLab(Integer labId) {
        return labReservationRepository.findByLabLabId(labId);
    }

    @Override
    public List<LabReservation> getLabReservationsByInstructor(Integer instructorId) {
        return labReservationRepository.findByInstructorInstructorId(instructorId);
    }

    @Override
    public List<LabReservation> getLabReservationsByDate(LocalDate date) {
        return labReservationRepository.findByDate(date);
    }

    @Override
    public List<LabReservation> getPendingLabReservations() {
        return labReservationRepository.findByStatus("PENDING");
    }

    @Override
    public LabReservation approveLabReservation(Integer id) {
        LabReservation reservation = getLabReservationById(id);
        
        // Check if lab is still available
        if (!checkLabAvailability(
                reservation.getLab().getLabId(),
                reservation.getDate(),
                reservation.getStartTime().toString(),
                reservation.getEndTime().toString())) {
            throw new RuntimeException("Cannot approve reservation. Lab is no longer available at the requested time.");
        }
        
        reservation.setStatus("APPROVED");
        return labReservationRepository.save(reservation);
    }

    @Override
    public LabReservation rejectLabReservation(Integer id) {
        LabReservation reservation = getLabReservationById(id);
        reservation.setStatus("REJECTED");
        return labReservationRepository.save(reservation);
    }

    @Override
    public boolean checkLabAvailability(Integer labId, LocalDate date, String startTime, String endTime) {
        // Get all APPROVED lab reservations for this lab on this date
        List<LabReservation> reservations = labReservationRepository
                .findByLabLabIdAndDateAndStatus(labId, date, "APPROVED");
        
        if (reservations.isEmpty()) {
            return true;
        }
        
        LocalTime requestedStart = LocalTime.parse(startTime);
        LocalTime requestedEnd = LocalTime.parse(endTime);
        
        for (LabReservation existingReservation : reservations) {
            LocalTime existingStart = existingReservation.getStartTime();
            LocalTime existingEnd = existingReservation.getEndTime();
            
            // Check for time overlap
            // Overlap occurs if: requestedStart < existingEnd AND requestedEnd > existingStart
            if (requestedStart.isBefore(existingEnd) && requestedEnd.isAfter(existingStart)) {
                return false; // Conflict found
            }
        }
        
        return true; // No conflicts
    }
}

