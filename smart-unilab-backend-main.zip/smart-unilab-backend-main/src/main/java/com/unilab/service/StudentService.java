package com.unilab.service;

import com.unilab.entity.Student;
import java.util.List;

public interface StudentService {
    Student createStudent(Student student);
    Student getStudentById(Integer id);
    Student getStudentByEmail(String email);
    List<Student> getAllStudents();
    Student updateStudent(Integer id, Student student);
    void deleteStudent(Integer id);
    List<Student> searchStudents(String keyword);
    List<Student> getStudentsByLabReservation(Integer labId);
}