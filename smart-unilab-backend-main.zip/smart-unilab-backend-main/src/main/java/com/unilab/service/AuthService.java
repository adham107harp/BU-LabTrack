package com.unilab.service;

import com.unilab.dto.AuthResponse;
import com.unilab.dto.LoginRequest;
import com.unilab.dto.RegisterRequest;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
}

