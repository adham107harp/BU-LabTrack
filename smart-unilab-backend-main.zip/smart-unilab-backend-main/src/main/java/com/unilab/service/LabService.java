package com.unilab.service;

import com.unilab.entity.Lab;
import java.util.List;

public interface LabService {
    Lab createLab(Lab lab);
    Lab getLabById(Integer id);
    List<Lab> getAllLabs();
    Lab updateLab(Integer id, Lab lab);
    void deleteLab(Integer id);
    List<Lab> searchLabs(String keyword);
    List<Lab> getLabsByLocation(String location);
    List<Lab> getAvailableLabs();
    boolean isLabAvailable(Integer labId);
}