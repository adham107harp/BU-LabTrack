package com.unilab.service;

import com.unilab.entity.Instructor;
import java.util.List;

public interface InstructorService {
    Instructor createInstructor(Instructor instructor);
    Instructor getInstructorById(Integer id);
    Instructor getInstructorByEmail(String email);
    List<Instructor> getAllInstructors();
    Instructor updateInstructor(Integer id, Instructor instructor);
    void deleteInstructor(Integer id);
    List<Instructor> searchInstructors(String keyword);

    boolean existsByEmail(String email);
}