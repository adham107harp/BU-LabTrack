package com.unilab.service;

import com.unilab.entity.SharedTool;
import java.util.List;

public interface SharedToolService {
    SharedTool createTool(SharedTool tool);
    SharedTool getToolById(Integer id);
    List<SharedTool> getAllTools();
    List<SharedTool> getToolsByOwner(Integer studentId);
    SharedTool updateTool(Integer id, SharedTool tool);
    void deleteTool(Integer id, Integer ownerStudentId); // Only owner can delete
    List<SharedTool> searchTools(String keyword);
}

