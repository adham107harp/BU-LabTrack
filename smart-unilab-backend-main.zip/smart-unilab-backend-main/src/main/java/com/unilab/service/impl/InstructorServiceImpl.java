package com.unilab.service.impl;

import com.unilab.entity.Instructor;
import com.unilab.repository.InstructorRepository;
import com.unilab.service.InstructorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class InstructorServiceImpl implements InstructorService {

    @Autowired
    private InstructorRepository instructorRepository;

    @Override
    public Instructor createInstructor(Instructor instructor) {
        if (instructorRepository.existsByEmail(instructor.getEmail())) {
            throw new RuntimeException("Email already exists: " + instructor.getEmail());
        }
        return instructorRepository.save(instructor);
    }

    @Override
    public Instructor getInstructorById(Integer id) {
        return instructorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Instructor not found with ID: " + id));
    }

    @Override
    public Instructor getInstructorByEmail(String email) {
        return instructorRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Instructor not found with email: " + email));
    }

    @Override
    public List<Instructor> getAllInstructors() {
        return instructorRepository.findAll();
    }

    @Override
    public Instructor updateInstructor(Integer id, Instructor instructor) {
        Instructor existingInstructor = getInstructorById(id);
        existingInstructor.setName(instructor.getName());
        existingInstructor.setEmail(instructor.getEmail());
        return instructorRepository.save(existingInstructor);
    }

    @Override
    public void deleteInstructor(Integer id) {
        if (!instructorRepository.existsById(id)) {
            throw new RuntimeException("Instructor not found with ID: " + id);
        }
        instructorRepository.deleteById(id);
    }

    @Override
    public List<Instructor> searchInstructors(String keyword) {
        return instructorRepository.findByNameContainingIgnoreCase(keyword);
    }

    @Override
    public boolean existsByEmail(String email) {
        return instructorRepository.existsByEmail(email);
    }
}