package com.unilab.service;

import com.unilab.entity.LabReservation;
import java.time.LocalDate;
import java.util.List;

public interface LabReservationService {
    LabReservation createLabReservation(LabReservation labReservation);
    LabReservation getLabReservationById(Integer id);
    List<LabReservation> getAllLabReservations();
    LabReservation updateLabReservation(Integer id, LabReservation labReservation);
    void deleteLabReservation(Integer id);
    List<LabReservation> getLabReservationsByLab(Integer labId);
    List<LabReservation> getLabReservationsByInstructor(Integer instructorId);
    List<LabReservation> getLabReservationsByDate(LocalDate date);
    List<LabReservation> getPendingLabReservations();
    LabReservation approveLabReservation(Integer id);
    LabReservation rejectLabReservation(Integer id);
    boolean checkLabAvailability(Integer labId, LocalDate date, String startTime, String endTime);
}

