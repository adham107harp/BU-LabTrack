package com.unilab.service.impl;

import com.unilab.entity.Lab;
import com.unilab.repository.LabRepository;
import com.unilab.service.LabService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class LabServiceImpl implements LabService {

    @Autowired
    private LabRepository labRepository;

    @Override
    public Lab createLab(Lab lab) {
        return labRepository.save(lab);
    }

    @Override
    public Lab getLabById(Integer id) {
        return labRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lab not found with ID: " + id));
    }

    @Override
    public List<Lab> getAllLabs() {
        return labRepository.findAll();
    }

    @Override
    public Lab updateLab(Integer id, Lab lab) {
        Lab existingLab = getLabById(id);
        existingLab.setLabName(lab.getLabName());
        existingLab.setLocation(lab.getLocation());
        existingLab.setCapacity(lab.getCapacity());
        existingLab.setRequiredLevel(lab.getRequiredLevel());
        existingLab.setInstructor(lab.getInstructor());
        return labRepository.save(existingLab);
    }

    @Override
    public void deleteLab(Integer id) {
        if (!labRepository.existsById(id)) {
            throw new RuntimeException("Lab not found with ID: " + id);
        }
        labRepository.deleteById(id);
    }

    @Override
    public List<Lab> searchLabs(String keyword) {
        return labRepository.findByLabNameContainingIgnoreCase(keyword);
    }

    @Override
    public List<Lab> getLabsByLocation(String location) {
        return labRepository.findByLocation(location);
    }

    @Override
    public List<Lab> getAvailableLabs() {
        // Return all labs for now - can be enhanced with date/time filtering
        return labRepository.findAll();
    }

    @Override
    public boolean isLabAvailable(Integer labId) {
        // Basic check - lab exists and is not deleted
        return labRepository.existsById(labId);
    }
}