package com.unilab.service.impl;

import com.unilab.entity.SharedTool;
import com.unilab.entity.Student;
import com.unilab.repository.SharedToolRepository;
import com.unilab.repository.StudentRepository;
import com.unilab.service.SharedToolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class SharedToolServiceImpl implements SharedToolService {

    @Autowired
    private SharedToolRepository sharedToolRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public SharedTool createTool(SharedTool tool) {
        // Validate owner exists
        Student owner = studentRepository.findById(tool.getOwner().getStudentId())
                .orElseThrow(() -> new RuntimeException("Owner student not found with ID: " + tool.getOwner().getStudentId()));
        
        // Validate email matches owner's email
        if (!tool.getContactEmail().equals(owner.getEmail())) {
            throw new RuntimeException("Contact email must match owner's university email");
        }
        
        tool.setOwner(owner);
        return sharedToolRepository.save(tool);
    }

    @Override
    public SharedTool getToolById(Integer id) {
        return sharedToolRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tool not found with ID: " + id));
    }

    @Override
    public List<SharedTool> getAllTools() {
        return sharedToolRepository.findAll();
    }

    @Override
    public List<SharedTool> getToolsByOwner(Integer studentId) {
        return sharedToolRepository.findByOwnerStudentId(studentId);
    }

    @Override
    public SharedTool updateTool(Integer id, SharedTool tool) {
        SharedTool existingTool = getToolById(id);
        
        // Only owner can update
        if (!existingTool.getOwner().getStudentId().equals(tool.getOwner().getStudentId())) {
            throw new RuntimeException("Only the tool owner can update this tool");
        }
        
        existingTool.setToolName(tool.getToolName());
        existingTool.setDescription(tool.getDescription());
        existingTool.setImageUrl(tool.getImageUrl());
        existingTool.setContactEmail(tool.getContactEmail());
        
        return sharedToolRepository.save(existingTool);
    }

    @Override
    public void deleteTool(Integer id, Integer ownerStudentId) {
        SharedTool tool = getToolById(id);
        
        // Only owner can delete
        if (!tool.getOwner().getStudentId().equals(ownerStudentId)) {
            throw new RuntimeException("Only the tool owner can delete this tool");
        }
        
        sharedToolRepository.deleteById(id);
    }

    @Override
    public List<SharedTool> searchTools(String keyword) {
        return sharedToolRepository.findByToolNameContainingIgnoreCase(keyword);
    }
}

