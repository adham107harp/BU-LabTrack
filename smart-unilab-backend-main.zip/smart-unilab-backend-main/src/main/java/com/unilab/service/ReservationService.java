package com.unilab.service;

import com.unilab.entity.Reservation;
import java.time.LocalDate;
import java.util.List;

public interface ReservationService {
    Reservation createReservation(Reservation reservation);
    Reservation getReservationById(Integer id);
    List<Reservation> getAllReservations();
    Reservation updateReservation(Integer id, Reservation reservation);
    void deleteReservation(Integer id);
    List<Reservation> getReservationsByEquipment(String equipmentName);
    List<Reservation> getReservationsByStudent(Integer studentId);
    List<Reservation> getReservationsByDate(LocalDate date);
    List<Reservation> getReservationsByEquipmentAndDate(String equipmentName, LocalDate date);
    boolean checkEquipmentAvailability(String equipmentName, LocalDate date, String startTime, String endTime);
    List<Reservation> getPendingReservations();
    Reservation approveReservation(Integer id);
    Reservation rejectReservation(Integer id);
    List<Reservation> getReservationsByLab(Integer labId);
}