package com.unilab.service.impl;

import com.unilab.entity.Research;
import com.unilab.repository.ResearchRepository;
import com.unilab.service.ResearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class ResearchServiceImpl implements ResearchService {

    @Autowired
    private ResearchRepository researchRepository;

    @Override
    public Research createResearch(Research research) {
        return researchRepository.save(research);
    }

    @Override
    public Research getResearchById(Integer id) {
        return researchRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Research not found with ID: " + id));
    }

    @Override
    public List<Research> getAllResearch() {
        return researchRepository.findAll();
    }

    @Override
    public Research updateResearch(Integer id, Research research) {
        Research existingResearch = getResearchById(id);
        existingResearch.setTitle(research.getTitle());
        existingResearch.setLab(research.getLab());
        existingResearch.setStudent(research.getStudent());
        existingResearch.setStartDate(research.getStartDate());
        existingResearch.setEndDate(research.getEndDate());
        return researchRepository.save(existingResearch);
    }

    @Override
    public void deleteResearch(Integer id) {
        if (!researchRepository.existsById(id)) {
            throw new RuntimeException("Research not found with ID: " + id);
        }
        researchRepository.deleteById(id);
    }

    @Override
    public List<Research> getResearchByLab(Integer labId) {
        return researchRepository.findByLabLabId(labId);
    }

    @Override
    public List<Research> getResearchByStudent(Integer studentId) {
        return researchRepository.findByStudentStudentId(studentId);
    }

    @Override
    public List<Research> searchResearch(String keyword) {
        return researchRepository.searchResearch(keyword);
    }
}

