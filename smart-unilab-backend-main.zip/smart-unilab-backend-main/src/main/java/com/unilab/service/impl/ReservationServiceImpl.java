package com.unilab.service.impl;

import com.unilab.entity.Reservation;
import com.unilab.repository.ReservationRepository;
import com.unilab.service.LabScheduleService;
import com.unilab.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ReservationServiceImpl implements ReservationService {

    private static final int BUFFER_MINUTES = 15; // 15 minutes gap between reservations

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private LabScheduleService labScheduleService;

    @Override
    public Reservation createReservation(Reservation reservation) {
        // Set status to PENDING (requires admin approval)
        reservation.setStatus("PENDING");
        
        LocalDate reservationDate = reservation.getDate();
        LocalTime reservationTime = reservation.getTime();
        LocalTime endTime = reservationTime.plusMinutes(reservation.getDuration());
        Integer labId = reservation.getEquipment().getLab().getLabId();
        
        // Validation 1: Check if time is within school hours (8 AM - 6 PM)
        if (!labScheduleService.isWithinSchoolHours(reservationTime)) {
            throw new RuntimeException("Reservations can only be made during school hours (8:00 AM - 6:00 PM).");
        }
        
        if (!labScheduleService.isWithinSchoolHours(endTime)) {
            throw new RuntimeException("Reservation end time must be within school hours (8:00 AM - 6:00 PM).");
        }
        
        // Validation 2: Check if lab has an active session at this time
        DayOfWeek dayOfWeek = reservationDate.getDayOfWeek();
        String dayName = labScheduleService.getDayOfWeekName(dayOfWeek);
        
        // Check if there's an active session during the reservation time
        if (labScheduleService.isLabInSession(labId, dayName, reservationTime)) {
            throw new RuntimeException("Cannot make reservation. The lab has an active session at this time. Please check the lab schedule.");
        }
        
        // Check if reservation overlaps with any session
        List<com.unilab.entity.LabSchedule> schedules = labScheduleService.getSchedulesByLabAndDay(labId, dayName);
        for (com.unilab.entity.LabSchedule schedule : schedules) {
            LocalTime sessionStart = schedule.getStartTime();
            LocalTime sessionEnd = schedule.getEndTime();
            
            // Check if reservation overlaps with session
            if ((reservationTime.isBefore(sessionEnd) && endTime.isAfter(sessionStart))) {
                throw new RuntimeException("Cannot make reservation. The reservation time overlaps with a scheduled lab session.");
            }
        }
        
        // Validation 3: Check equipment availability with 15-minute buffer
        if (!checkEquipmentAvailability(
                reservation.getEquipment().getEquipmentName(),
                reservation.getDate(),
                reservation.getTime().toString(),
                endTime.toString())) {
            throw new RuntimeException("Equipment is not available at the requested time. There is a conflict with an existing approved reservation or insufficient gap between reservations.");
        }
        
        return reservationRepository.save(reservation);
    }

    @Override
    public Reservation getReservationById(Integer id) {
        return reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reservation not found with ID: " + id));
    }

    @Override
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    @Override
    public Reservation updateReservation(Integer id, Reservation reservation) {
        Reservation existingReservation = getReservationById(id);
        existingReservation.setEquipment(reservation.getEquipment());
        existingReservation.setStudent(reservation.getStudent());
        existingReservation.setSupervisor(reservation.getSupervisor());
        existingReservation.setDate(reservation.getDate());
        existingReservation.setTime(reservation.getTime());
        existingReservation.setDuration(reservation.getDuration());
        existingReservation.setPurpose(reservation.getPurpose());
        existingReservation.setReservationType(reservation.getReservationType());
        existingReservation.setTeamSize(reservation.getTeamSize());
        return reservationRepository.save(existingReservation);
    }

    @Override
    public void deleteReservation(Integer id) {
        if (!reservationRepository.existsById(id)) {
            throw new RuntimeException("Reservation not found with ID: " + id);
        }
        reservationRepository.deleteById(id);
    }

    @Override
    public List<Reservation> getReservationsByEquipment(String equipmentName) {
        return reservationRepository.findByEquipmentEquipmentName(equipmentName);
    }

    @Override
    public List<Reservation> getReservationsByStudent(Integer studentId) {
        return reservationRepository.findByStudentStudentId(studentId);
    }

    @Override
    public List<Reservation> getReservationsByDate(LocalDate date) {
        return reservationRepository.findByDate(date);
    }

    @Override
    public List<Reservation> getReservationsByEquipmentAndDate(String equipmentName, LocalDate date) {
        return reservationRepository.findByEquipmentEquipmentNameAndDate(equipmentName, date);
    }

    @Override
    public boolean checkEquipmentAvailability(String equipmentName, LocalDate date, String startTime, String endTime) {
        // Additional validation: Check if time is within school hours
        LocalTime requestedStart = LocalTime.parse(startTime);
        LocalTime requestedEnd = LocalTime.parse(endTime);
        
        if (!labScheduleService.isWithinSchoolHours(requestedStart) || !labScheduleService.isWithinSchoolHours(requestedEnd)) {
            return false; // Outside school hours
        }
        
        // Get all APPROVED reservations for this equipment on this date
        List<Reservation> reservations = getReservationsByEquipmentAndDate(equipmentName, date)
                .stream()
                .filter(r -> "APPROVED".equals(r.getStatus()))
                .collect(Collectors.toList());
        
        if (reservations.isEmpty()) {
            return true;
        }
        
        // Validate that requested start is before requested end
        if (!requestedStart.isBefore(requestedEnd)) {
            return false; // Invalid time range
        }
        
        for (Reservation existingReservation : reservations) {
            LocalTime existingStart = existingReservation.getTime();
            LocalTime existingEnd = existingStart.plusMinutes(existingReservation.getDuration());
            
            // Add 15-minute buffer before and after each existing reservation
            LocalTime bufferStart = existingStart.minusMinutes(BUFFER_MINUTES);
            LocalTime bufferEnd = existingEnd.plusMinutes(BUFFER_MINUTES);
            
            // Check for time overlap including buffer
            // Overlap occurs if: requestedStart < bufferEnd AND requestedEnd > bufferStart
            // This handles all cases: before, during, after, and exact matches
            if (requestedStart.isBefore(bufferEnd) && requestedEnd.isAfter(bufferStart)) {
                return false; // Conflict found (including buffer)
            }
        }
        
        return true; // No conflicts
    }

    @Override
    public List<Reservation> getPendingReservations() {
        return reservationRepository.findByStatus("PENDING");
    }

    @Override
    public Reservation approveReservation(Integer id) {
        Reservation reservation = getReservationById(id);
        
        LocalDate reservationDate = reservation.getDate();
        LocalTime reservationTime = reservation.getTime();
        LocalTime endTime = reservationTime.plusMinutes(reservation.getDuration());
        Integer labId = reservation.getEquipment().getLab().getLabId();
        
        // Re-validate school hours
        if (!labScheduleService.isWithinSchoolHours(reservationTime) || !labScheduleService.isWithinSchoolHours(endTime)) {
            throw new RuntimeException("Cannot approve reservation. Time is outside school hours (8:00 AM - 6:00 PM).");
        }
        
        // Re-validate lab sessions
        DayOfWeek dayOfWeek = reservationDate.getDayOfWeek();
        String dayName = labScheduleService.getDayOfWeekName(dayOfWeek);
        
        if (labScheduleService.isLabInSession(labId, dayName, reservationTime)) {
            throw new RuntimeException("Cannot approve reservation. The lab has an active session at this time.");
        }
        
        // Check if equipment is still available (might have been booked while pending)
        if (!checkEquipmentAvailability(
                reservation.getEquipment().getEquipmentName(),
                reservation.getDate(),
                reservation.getTime().toString(),
                endTime.toString())) {
            throw new RuntimeException("Cannot approve reservation. Equipment is no longer available at the requested time.");
        }
        
        reservation.setStatus("APPROVED");
        return reservationRepository.save(reservation);
    }

    @Override
    public Reservation rejectReservation(Integer id) {
        Reservation reservation = getReservationById(id);
        reservation.setStatus("REJECTED");
        return reservationRepository.save(reservation);
    }

    @Override
    public List<Reservation> getReservationsByLab(Integer labId) {
        return reservationRepository.findByEquipmentLabLabId(labId);
    }
}
