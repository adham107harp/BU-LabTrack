package com.unilab.seed;

import com.unilab.entity.*;
import com.unilab.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;

@Slf4j
@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private InstructorRepository instructorRepository;

    @Autowired
    private LabRepository labRepository;

    @Autowired
    private EquipmentRepository equipmentRepository;

    @Autowired
    private TechnicianRepository technicianRepository;

    @Override
    public void run(String... args) throws Exception {
        seedInstructors();
        seedLabs();
        seedStudents();
        seedEquipment();
        seedTechnicians();

        System.out.println("✅ Database seeding completed!");
        System.out.println("📊 Stats:");
        System.out.println("   Students: " + studentRepository.count());
        System.out.println("   Instructors: " + instructorRepository.count());
        System.out.println("   Labs: " + labRepository.count());
        System.out.println("   Equipment: " + equipmentRepository.count());
        log.info("   Technicians: {}",
                technicianRepository.count());
    }

    private void seedInstructors() {
        if (instructorRepository.count() == 0) {
            instructorRepository.saveAll(Arrays.asList(
                    new Instructor(84026, "Abeer Sarhan", "Abeer.Mahmoud@badyauni.edu.eg"),
                    new Instructor(8004011, "Nouran Mohamed", "Nouran.Mohamed@badyauni.edu.eg"),
                    new Instructor(8004012, "Rana Hamed", "Rana.Hamed@badyauni.edu.eg"),
                    new Instructor(8004014, "Ziad Nabil", "Ziad.Nabil@badyauni.edu.eg"),
                    new Instructor(8004023, "Seham Ahmed", "Seham.Ahmed@badyauni.edu.eg"),
                    new Instructor(8004025, "Mohamed Abdo", "Mohamed.Abdo@badyauni.edu.eg"),
                    new Instructor(8004027, "Abdelrhman Sherif", "Abdelrahman.Sherif@badyauni.edu.eg"),
                    new Instructor(8004035, "Salwa Mabrouk", "Salwa.Mabrouk@badyauni.edu.eg")
            ));
            System.out.println("✅ Instructors seeded");
        }
    }

    private void seedLabs() {
        if (labRepository.count() == 0) {
            Instructor instructor1 = instructorRepository.findById(84026).orElse(null);

            labRepository.saveAll(Arrays.asList(
                    new Lab(1, "Physics Lab", "Ground Floor", 30, instructor1, 2500),
                    new Lab(15, "Digital Logic Design Lab", "Ground Floor", 30, null, 2500),
                    new Lab(134, "Computer Lab", "First Floor", 30, null, 2500),
                    new Lab(135, "Computer Lab", "First Floor", 30, null, 2500),
                    new Lab(243, "Robotics Lab", "Second Floor", 30, null, 2500),
                    new Lab(244, "Physics Lab", "Second Floor", 30, null, 2500),
                    new Lab(245, "Virtual Reality Lab", "Second Floor", 30, null, 2500),
                    new Lab(246, "Digital Logic Design Lab", "Second Floor", 30, null, 2500),
                    new Lab(247, "Computer Lab", "Second Floor", 30, null, 2500),
                    new Lab(250, "Computer Lab", "Second Floor", 30, null, 2500),
                    new Lab(251, "CyberSecurity Lab", "Second Floor", 30, null, 2500),
                    new Lab(255, "Research Lab", "Second Floor", 10, null, 2500),
                    new Lab(256, "Research Lab", "Second Floor", 10, null, 2500)
            ));
            System.out.println("✅ Labs seeded");
        }
    }

    private void seedStudents() {
        if (studentRepository.count() == 0) {
            studentRepository.saveAll(Arrays.asList(
                    new Student(2400378, "Nadine Ahmed Mahmoud Hamza", "n.ahmed2400378@badyauni.edu.eg"),
                    new Student(2400487, "Mohaned Mouneer Ibrahim Abdelaal", "m.mouneer2400487@badyauni.edu.eg"),
                    new Student(2400517, "Adham Mohammed Ateia Elsaeed", "a.mohammed2400517@badyauni.edu.eg"),
                    new Student(2400519, "Mohamed Arafat Eid Elmohamdy", "m.arafat2400519@badyauni.edu.eg"),
                    new Student(2400556, "Moaz Ahmed Abdallah Faragallah", "m.ahmed2400556@badyauni.edu.eg")
            ));
            System.out.println("✅ Students seeded");
        }
    }

    private void seedEquipment() {
        if (equipmentRepository.count() == 0) {
            Lab physicsLab = labRepository.findById(1).orElse(null);
            Lab digitalLab = labRepository.findById(15).orElse(null);

            equipmentRepository.saveAll(Arrays.asList(
                    new Equipment("2 MHz Function Generator", "", digitalLab),
                    new Equipment("Characteristic Curve of Diode & LED", "", physicsLab),
                    new Equipment("Characteristic Curve of Transistor", "", physicsLab),
                    new Equipment("Charging & Discharging of Capacitor", "", physicsLab),
                    new Equipment("Digital Storage Oscilloscope 100 MHz", "", digitalLab),
                    new Equipment("Hook's Law", "", physicsLab),
                    new Equipment("Kirchhoff's Law Experiment", "", physicsLab),
                    new Equipment("Law of Lenses and Optical Instruments", "", physicsLab),
                    new Equipment("Measurement of Basic Constants", "", physicsLab),
                    new Equipment("Ohm's Law Experiment", "", physicsLab),
                    new Equipment("Simple Pendulum", "", physicsLab),
                    new Equipment("Viscosity", "", physicsLab)
            ));
            System.out.println("✅ Equipment seeded");
        }
    }

    private void seedTechnicians() {
        if (technicianRepository.count() == 0) {
            technicianRepository.saveAll(Arrays.asList(
                    new Technician(9001, "Ahmed Hassan", "Physics Lab"),
                    new Technician(9002, "Mona Ali", "Physics Lab"),
                    new Technician(9003, "Khaled Samir", "Digital Logic Lab"),
                    new Technician(9004, "Sara Mohamed", "Computer Lab"),
                    new Technician(9005, "Omar Tarek", "Robotics Lab"),
                    new Technician(9006, "Laila Nabil", "CyberSecurity Lab"),
                    new Technician(9007, "Mohamed Salah", "Virtual Reality Lab"),
                    new Technician(9008, "Aya Mahmoud", "Research Lab")
            ));
            System.out.println("✅ Technicians seeded");
        }
    }
}