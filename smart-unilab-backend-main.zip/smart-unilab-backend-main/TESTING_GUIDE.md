# دليل اختبار Smart UniLab Backend

## 🚀 طرق الاختبار

### 1. استخدام Swagger UI (الأسهل والأفضل)

1. شغل التطبيق
2. افتح المتصفح واذهب إلى:
   ```
   http://localhost:8080/swagger-ui.html
   ```
3. ستجد كل الـ APIs منظمة ويمكنك:
   - تجربة كل endpoint مباشرة
   - رؤية الـ Request/Response
   - اختبار الـ validation

---

### 2. استخدام HTML Dashboard

1. شغل التطبيق
2. افتح:
   ```
   http://localhost:8080/index.html
   ```
3. ستجد أزرار جاهزة لاختبار:
   - Students
   - Labs
   - Equipment
   - Instructors
   - **Shared Tools** (الجديد!)

---

### 3. استخدام Postman أو cURL

#### أ) اختبار Shared Tools

**1. إنشاء أداة جديدة:**
```bash
POST http://localhost:8080/api/shared-tools
Content-Type: application/json

{
  "toolName": "Arduino Kit",
  "description": "Complete Arduino starter kit with sensors",
  "imageUrl": "https://example.com/arduino.jpg",
  "ownerStudentId": 2400378
}
```

**2. جلب كل الأدوات:**
```bash
GET http://localhost:8080/api/shared-tools
```

**3. جلب أداة محددة:**
```bash
GET http://localhost:8080/api/shared-tools/1
```

**4. جلب أدوات طالب محدد:**
```bash
GET http://localhost:8080/api/shared-tools/owner/2400378
```

**5. البحث عن أدوات:**
```bash
GET http://localhost:8080/api/shared-tools/search?keyword=arduino
```

**6. تحديث أداة (فقط المالك):**
```bash
PUT http://localhost:8080/api/shared-tools/1
Content-Type: application/json

{
  "toolName": "Arduino Kit Pro",
  "description": "Updated description",
  "imageUrl": "https://example.com/arduino-pro.jpg",
  "ownerStudentId": 2400378
}
```

**7. حذف أداة (فقط المالك):**
```bash
DELETE http://localhost:8080/api/shared-tools/1?ownerStudentId=2400378
```

#### ب) اختبار منطق الحجوزات الجديد

**1. إنشاء حجز (مع فحص التعارض):**
```bash
POST http://localhost:8080/api/reservations
Content-Type: application/json

{
  "reservationId": 1,
  "lab": {"labId": 1},
  "student": {"studentId": 2400378},
  "date": "2025-12-15",
  "time": "10:00:00",
  "duration": 120,
  "purpose": "Project work",
  "reservationType": "Individual",
  "teamSize": 1
}
```

**2. فحص توفر المعمل:**
```bash
GET http://localhost:8080/api/reservations/check-availability?labId=1&date=2025-12-15&startTime=10:00:00&endTime=12:00:00
```

**3. جلب حجوزات معمل محدد:**
```bash
GET http://localhost:8080/api/reservations/lab/1
```

**4. جلب حجوزات طالب محدد:**
```bash
GET http://localhost:8080/api/reservations/student/2400378
```

#### ج) اختبار الطلاب الذين لديهم حجوزات في معمل

```bash
GET http://localhost:8080/api/students?labId=1
# أو
GET http://localhost:8080/api/students/reservations/lab/1
```

---

## 📋 سيناريوهات الاختبار

### سيناريو 1: مشاركة أداة

1. **تسجيل أداة:**
   - استخدم `POST /api/shared-tools` مع بيانات طالب موجود (مثل 2400378)
   - تأكد أن الإيميل يأخذ تلقائياً من بيانات الطالب

2. **عرض الأدوات:**
   - استخدم `GET /api/shared-tools` لرؤية كل الأدوات
   - استخدم `GET /api/shared-tools/owner/2400378` لرؤية أدوات طالب محدد

3. **البحث:**
   - استخدم `GET /api/shared-tools/search?keyword=arduino`

4. **الحذف:**
   - جرب حذف أداة بمستخدم غير المالك (يجب أن يفشل)
   - جرب حذف أداة بالمالك (يجب أن ينجح)

### سيناريو 2: فحص تعارض الحجوزات

1. **إنشاء حجز أول:**
   - معمل 1، تاريخ 2025-12-15، من 10:00 إلى 12:00

2. **محاولة حجز متعارض:**
   - نفس المعمل، نفس التاريخ، من 11:00 إلى 13:00
   - يجب أن يفشل مع رسالة خطأ

3. **حجز غير متعارض:**
   - نفس المعمل، نفس التاريخ، من 13:00 إلى 15:00
   - يجب أن ينجح

---

## 🔍 التحقق من قاعدة البيانات

### استخدام H2 Console

1. افتح: `http://localhost:8080/h2-console`
2. بيانات الدخول:
   - JDBC URL: `jdbc:h2:mem:smartunilabdb`
   - Username: `sa`
   - Password: (فارغ)

3. استعلامات مفيدة:

```sql
-- رؤية كل الأدوات المشتركة
SELECT * FROM shared_tool;

-- رؤية الحجوزات
SELECT * FROM reservation;

-- رؤية الطلاب
SELECT * FROM student;

-- رؤية الأدوات مع بيانات المالك
SELECT t.*, s.name as owner_name, s.email as owner_email 
FROM shared_tool t 
JOIN student s ON t.owner_student_id = s.studentid;
```

---

## ⚠️ حالات الخطأ المتوقعة

### Shared Tools:
- ❌ إنشاء أداة بطالب غير موجود → خطأ 400
- ❌ حذف أداة بمستخدم غير المالك → خطأ 400
- ❌ إيميل غير مطابق لإيميل المالك → خطأ 400

### Reservations:
- ❌ حجز متعارض مع حجز موجود → خطأ 400
- ❌ حجز بمعمل غير موجود → خطأ 404

---

## 🎯 نصائح للاختبار

1. **ابدأ بـ Swagger UI** - أسهل طريقة
2. **استخدم البيانات الموجودة** - التطبيق فيه بيانات seed جاهزة
3. **اختبر حالات الخطأ** - مهم جداً
4. **راجع قاعدة البيانات** - للتأكد من حفظ البيانات

---

## 📝 ملاحظات

- كل الـ APIs تدعم CORS
- الـ validation يعمل تلقائياً
- الأخطاء ترجع JSON منظم
- الصور حالياً URLs خارجية (يمكن تطويرها لاحقاً)

