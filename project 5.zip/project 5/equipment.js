document.addEventListener('DOMContentLoaded', function() {

    // Get all necessary elements
    const addBtn = document.getElementById('add-equipment-btn');
    const modal = document.getElementById('add-equipment-modal');
    const closeBtn = document.querySelector('.close-button');
    const form = document.getElementById('new-equipment-form');
    const equipmentList = document.getElementById('equipment-list');
    const emptyMessage = document.getElementById('empty-message');

    // Array to store added equipment (Front-end only)
    let equipmentData = [];

    // --- Modal Control Functions ---

    // Open the modal
    addBtn.onclick = function() {
        modal.style.display = "block";
    }

    // Close the modal using the (X) button
    closeBtn.onclick = function() {
        modal.style.display = "none";
    }

    // Close the modal if the user clicks outside of it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // --- Data Rendering and Form Submission ---

    // Function to render the equipment list
    function renderEquipmentList() {
        equipmentList.innerHTML = ''; // Clear the current list

        if (equipmentData.length === 0) {
            equipmentList.appendChild(emptyMessage);
            emptyMessage.style.display = 'block';
        } else {
            emptyMessage.style.display = 'none';
            equipmentData.forEach(item => {
                const card = document.createElement('div');
                card.className = 'equipment-card';
                card.innerHTML = `
                    <h3>${item.name}</h3>
                    <p>Contact: <a href="mailto:${item.email}">${item.email}</a></p>
                    <p>Added: ${new Date().toLocaleDateString()}</p>
                `;
                equipmentList.appendChild(card);
            });
        }
    }

    // Handle form submission
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Get values from the fields
        const equipmentName = document.getElementById('equipment-name').value;
        const contactEmail = document.getElementById('contact-email').value;

        // Add the new item to the array
        equipmentData.push({
            name: equipmentName,
            email: contactEmail,
            date: new Date().toISOString()
        });

        // Update the displayed list
        renderEquipmentList();

        // Reset the form and close the modal
        form.reset();
        modal.style.display = "none";

        // Success feedback (optional)
        alert(`Tool "${equipmentName}" successfully added for sharing.`);
    });

    // Initial render when the page loads
    renderEquipmentList();
});