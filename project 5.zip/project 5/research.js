document.addEventListener('DOMContentLoaded', function() {

    const bookingForm = document.getElementById('faculty-booking-form');

    if (bookingForm) {
        bookingForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Stop traditional form submission

            const formData = new FormData(bookingForm);
            const bookingDetails = Object.fromEntries(formData.entries());

            // --- Front-end Simulation ---

            // Check for basic data
            if (bookingDetails.researchLab && bookingDetails.bookingDate && bookingDetails.timeFrom && bookingDetails.timeTo) {

                // Show a success message to the doctor/faculty member
                alert(`SUCCESS! Time slot requested for ${bookingDetails.researchLab} on ${bookingDetails.bookingDate} from ${bookingDetails.timeFrom} to ${bookingDetails.timeTo}. Your request has been sent for approval.`);

                // Clear the form
                bookingForm.reset();

                // In a real application, this data would be sent to the server here.

            } else {
                alert('Please fill out all booking details.');
            }
        });
    }
});