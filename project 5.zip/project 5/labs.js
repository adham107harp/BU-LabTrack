document.addEventListener('DOMContentLoaded', function() {
    // 1. Load Initial Lab Data
    const labDataElement = document.getElementById('initial-lab-data');
    // Parse the JSON data from the HTML script tag
    const labData = JSON.parse(labDataElement.textContent);
    const labTableBody = document.getElementById('lab-data-body');
    const filterForm = document.getElementById('lab-filter-form');

    // Function to render the lab data into the table
    function renderLabTable(data) {
        labTableBody.innerHTML = ''; // Clear existing data

        data.forEach(lab => {
            const row = labTableBody.insertRow();

            // Determine status class
            const statusClass = lab.status === 'Available' ? 'status-available' : 'status-busy';

            // Populate cells, using data-label for mobile responsiveness
            row.insertCell().textContent = lab.id; // Lab ID
            row.insertCell().textContent = lab.type; // Type
            row.insertCell().textContent = lab.floor; // Floor
            row.insertCell().textContent = lab.capacity; // Capacity

            // Status Cell
            const statusCell = row.insertCell();
            statusCell.innerHTML = `<span class="${statusClass}">${lab.status}</span>`;
            statusCell.setAttribute('data-label', 'Status');

            // Action Button
            const actionCell = row.insertCell();
            if (lab.status === 'Available') {
                actionCell.innerHTML = `<button class="action-button">Book Now</button>`;
            } else {
                actionCell.innerHTML = `<button class="action-button" disabled>View Schedule</button>`;
            }
            actionCell.setAttribute('data-label', 'Action');

            // Add mobile labels (Crucial for mobile CSS)
            row.cells[0].setAttribute('data-label', 'Lab ID');
            row.cells[1].setAttribute('data-label', 'Type');
            row.cells[2].setAttribute('data-label', 'Floor');
            row.cells[3].setAttribute('data-label', 'Capacity');
        });
    }

    // 2. Initial render when the page loads
    renderLabTable(labData);

    // 3. Handle Filtering/Search logic
    filterForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form from submitting traditionally

        // Get filter values
        const selectedType = document.getElementById('lab-type').value;
        const selectedFloor = document.getElementById('floor').value;
        const timeFrom = document.getElementById('time-from').value;
        const timeTo = document.getElementById('time-to').value;

        // Note: Filtering by Time Slot is complex and requires Back-end data (schedule)
        // For Front-end simulation, we will only filter by Type and Floor.

        let filteredData = labData.filter(lab => {
            const typeMatch = !selectedType || lab.type === selectedType;
            const floorMatch = !selectedFloor || lab.floor === selectedFloor;
            // You would add time slot logic here (e.g., checking if the lab is booked during timeFrom to timeTo)

            return typeMatch && floorMatch;
        });

        // Re-render the table with filtered data
        renderLabTable(filteredData);

        // Simple feedback for time filtering (since we can't implement full scheduling logic in pure front-end)
        if (timeFrom || timeTo) {
            alert(`Simulating search for labs available from ${timeFrom} to ${timeTo}. Displaying results filtered by Type and Floor only.`);
        }
    });
});