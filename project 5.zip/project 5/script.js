document.addEventListener('DOMContentLoaded', function() {
    // Get the navigation bar element
    const navbar = document.getElementById("navbar");

    // Function to change the navbar appearance on scroll
    window.addEventListener('scroll', function() {
        // Check if the user has scrolled down more than 50 pixels
        if (window.scrollY > 50) {
            // Apply a subtle box shadow and reduce padding
            navbar.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
            navbar.style.padding = '0.7rem 5%';
        } else {
            // Return to the original state at the top of the page
            navbar.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
            navbar.style.padding = '1rem 5%';
        }
    });

    // Additional JavaScript features (like counter animations or form validation) can be added here.
});