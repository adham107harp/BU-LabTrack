document.addEventListener('DOMContentLoaded', function() {
    // 1. Get the login form element using its ID
    const loginForm = document.getElementById('login-form');

    if (loginForm) {
        // 2. Add an event listener for when the form is submitted
        loginForm.addEventListener('submit', function(event) {

            // Prevent the default form submission behavior (which reloads the page)
            event.preventDefault();

            // --- Front-end simulation of successful login ---

            // In a real application, you would send the email/password to a server here.
            // For this project, we assume the login is successful.

            // 3. Get input values (Optional, but good practice)
            const emailInput = document.getElementById('university-email').value;
            const passwordInput = document.getElementById('password').value;

            // 4. (Optional) Basic dummy check
            if (emailInput && passwordInput) {

                // 5. Redirect the user to the Dashboard page
                // This command changes the browser's current location (URL)
                window.location.href = 'dashboard.html';

            } else {
                // Should not happen if inputs are marked 'required', but good for robustness
                alert('Please enter both your university email and password.');
            }

        });
    }
});